import SwiftUI

let accentBlue = Color(red: 0.08, green: 0.49, blue: 0.98)
let accentGreen = Color(red: 0.13, green: 0.77, blue: 0.37)

func cardBackground(_ dark: Bool) -> Color {
    dark ? Color(red: 0.13, green: 0.13, blue: 0.15) : Color(red: 0.97, green: 0.97, blue: 0.99)
}

func pageBackground(_ dark: Bool) -> Color {
    dark ? Color(red: 0.08, green: 0.08, blue: 0.10) : Color(red: 0.94, green: 0.95, blue: 0.98)
}

func primaryText(_ dark: Bool) -> Color {
    dark ? .white : Color(red: 0.1, green: 0.1, blue: 0.1)
}

func secondaryText(_ dark: Bool) -> Color {
    dark ? Color.white.opacity(0.6) : Color(red: 0.35, green: 0.35, blue: 0.35)
}

func sheetButtonBG(_ dark: Bool) -> Color {
    dark ? Color.white.opacity(0.10) : Color(red: 0.88, green: 0.88, blue: 0.90)
}

func sheetMessageBG(_ dark: Bool) -> Color {
    dark ? Color.white.opacity(0.07) : Color(red: 0.90, green: 0.90, blue: 0.92)
}

func profileColor(_ profile: UserProfile) -> Color {
    switch profile {
    case .ahorro: return accentGreen
    case .balanceado: return accentBlue
    case .confort: return Color(red: 0.85, green: 0.45, blue: 0.0)
    }
}

func consumptionBorderColor(_ consumption: Double, _ isOn: Bool) -> Color {
    guard isOn else { return Color.clear }
    switch consumption {
    case ..<0.3: return Color(red: 0.13, green: 0.77, blue: 0.37)
    case 0.3..<0.8: return Color(red: 1.0, green: 0.55, blue: 0.0)
    default: return Color(red: 0.9, green: 0.2, blue: 0.2)
    }
}

struct StatCard: View {
    let value: String
    let unit: String
    let color: Color
    let icon: String
    let dark: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: icon).foregroundColor(color).font(.system(size: 15))
                .accessibilityHidden(true)
            Text(value)
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(primaryText(dark))
                .minimumScaleFactor(0.6).lineLimit(1)
            Text(unit)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(secondaryText(dark))
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(cardBackground(dark))
        .cornerRadius(18)
        .shadow(color: .black.opacity(dark ? 0.3 : 0.06), radius: 8, x: 0, y: 4)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(value) \(unit)")
    }
}

struct TabBtn: View {
    let title: String
    let icon: String
    let selected: Bool
    let dark: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 16))
                Text(title).font(.system(size: 10, weight: .medium))
            }
            .foregroundColor(selected ? accentBlue : secondaryText(dark))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(selected ? accentBlue.opacity(0.12) : Color.clear)
            .cornerRadius(12)
        }
        .accessibilityLabel(title)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

struct ModeCard: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    let isActive: Bool
    let dark: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                ZStack {
                    Circle()
                        .fill(isActive ? color : color.opacity(0.12))
                        .frame(width: 48, height: 48)
                    Image(systemName: icon)
                        .foregroundColor(isActive ? .white : color)
                        .font(.system(size: 20))
                }
                Text(title)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(primaryText(dark))
                Text(subtitle)
                    .font(.system(size: 10))
                    .foregroundColor(secondaryText(dark))
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(isActive ? color.opacity(0.1) : cardBackground(dark))
            .cornerRadius(20)
            .shadow(color: .black.opacity(dark ? 0.3 : 0.05), radius: 6, x: 0, y: 3)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(isActive ? color.opacity(0.5) : Color.clear, lineWidth: 1.5)
            )
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title), \(subtitle)")
        .accessibilityValue(isActive ? "Activado" : "Desactivado")
        .accessibilityHint("Toca para activar este modo")
    }
}

struct DeviceCard: View {
    @Binding var device: HomeDevice
    let dark: Bool
    let onDelete: () -> Void

    @State private var showDeleteConfirm = false

    var borderColor: Color {
        consumptionBorderColor(device.consumption, device.isOn)
    }

    var iconColor: Color {
        device.isOn ? borderColor : secondaryText(dark).opacity(0.4)
    }

    var body: some View {
        ZStack {
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top) {
                    Image(systemName: device.icon)
                        .renderingMode(.template)
                        .foregroundColor(iconColor)
                        .font(.system(size: 24))
                    Spacer()
                    Toggle("", isOn: $device.isOn)
                        .labelsHidden()
                        .scaleEffect(0.75)
                        .tint(borderColor == Color.clear ? accentBlue : borderColor)
                        .allowsHitTesting(false)
                }
                .padding(.bottom, 10)

                Text(device.name)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(device.isOn ? primaryText(dark) : secondaryText(dark))
                Text(device.room)
                    .font(.system(size: 11))
                    .foregroundColor(secondaryText(dark))
                    .padding(.top, 1)

                Spacer()

                if device.isCharging {
                    HStack(spacing: 4) {
                        Image(systemName: "bolt.fill").foregroundColor(accentGreen).font(.system(size: 9))
                        Text("\(device.chargeLevel)%").font(.system(size: 11, weight: .medium)).foregroundColor(accentGreen)
                    }
                } else if device.isOn {
                    Text(String(format: "%.2f kW", device.consumption))
                        .font(.system(size: 11)).foregroundColor(secondaryText(dark))
                } else {
                    Text("Apagado")
                        .font(.system(size: 11)).foregroundColor(secondaryText(dark).opacity(0.5))
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(device.isOn ? borderColor.opacity(dark ? 0.12 : 0.07) : cardBackground(dark))
            .cornerRadius(20)
            .shadow(color: .black.opacity(device.isOn ? 0.08 : 0.03), radius: 8, x: 0, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(borderColor, lineWidth: device.isOn ? 1.8 : 0)
            )

            Color.clear
                .contentShape(Rectangle())
                .gesture(
                    LongPressGesture(minimumDuration: 0.5)
                        .onEnded { _ in
                            showDeleteConfirm = true
                        }
                )
                .simultaneousGesture(
                    TapGesture()
                        .onEnded {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                device.isOn.toggle()
                            }
                        }
                )
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(device.name) en \(device.room)")
        .accessibilityValue(device.isOn ? "Encendido. Consumo de \(String(format: "%.2f", device.consumption)) kilowatts" : "Apagado")
        .accessibilityHint("Doble toque para cambiar estado. Mantén presionado para eliminar.")
        .alert("¿Eliminar \(device.name)?", isPresented: $showDeleteConfirm) {
            Button("Eliminar", role: .destructive) { onDelete() }
            Button("Cancelar", role: .cancel) {}
        }
    }
}

struct AddDeviceSheet: View {
    let dark: Bool
    let onAdd: (HomeDevice) -> Void
    let onDismiss: () -> Void

    @State private var name = ""
    @State private var room = ""
    @State private var selectedIcon = "lightbulb.fill"
    @State private var showingHomeKit = false

    let icons = [
        "lightbulb.fill", "tv.fill", "snowflake", "washer.fill",
        "refrigerator.fill", "fan.fill", "oven.fill", "lamp.desk.fill",
        "iphone", "powerplug.fill", "air.conditioner.horizontal.fill", "speaker.wave.2.fill"
    ]

    let rooms = ["Sala", "Recámara", "Cocina", "Baño", "Lavandería", "Oficina", "Garaje", "Jardín"]

    let defaultConsumption: [String: Double] = [
        "lightbulb.fill": 0.06,
        "tv.fill": 0.15,
        "snowflake": 1.2,
        "washer.fill": 0.5,
        "refrigerator.fill": 0.15,
        "fan.fill": 0.07,
        "oven.fill": 1.8,
        "lamp.desk.fill": 0.04,
        "iphone": 0.02,
        "powerplug.fill": 0.1,
        "air.conditioner.horizontal.fill": 1.4,
        "speaker.wave.2.fill": 0.05
    ]

    var body: some View {
        VStack(spacing: 20) {
            RoundedRectangle(cornerRadius: 3)
                .fill(secondaryText(dark).opacity(0.4))
                .frame(width: 40, height: 5)
                .padding(.top, 12)
                .accessibilityHidden(true)

            Text("Agregar Dispositivo")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(primaryText(dark))
                .accessibilityAddTraits(.isHeader)

            VStack(spacing: 14) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Nombre")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(secondaryText(dark))
                    TextField("Ej. Lámpara del estudio", text: $name)
                        .font(.system(size: 14))
                        .foregroundColor(primaryText(dark))
                        .padding(12)
                        .background(sheetMessageBG(dark))
                        .cornerRadius(12)
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text("Habitación")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(secondaryText(dark))
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(rooms, id: \.self) { r in
                                Button { room = r } label: {
                                    Text(r)
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(room == r ? .white : primaryText(dark))
                                        .padding(.horizontal, 12).padding(.vertical, 7)
                                        .background(room == r ? accentBlue : sheetMessageBG(dark))
                                        .cornerRadius(10)
                                }
                                .accessibilityLabel("Habitación \(r)")
                                .accessibilityAddTraits(room == r ? .isSelected : [])
                            }
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text("Tipo de dispositivo")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(secondaryText(dark))
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 10) {
                        ForEach(icons, id: \.self) { ic in
                            Button { selectedIcon = ic } label: {
                                Image(systemName: ic)
                                    .font(.system(size: 18))
                                    .foregroundColor(selectedIcon == ic ? .white : primaryText(dark))
                                    .frame(width: 40, height: 40)
                                    .background(selectedIcon == ic ? accentBlue : sheetMessageBG(dark))
                                    .cornerRadius(10)
                            }
                            .accessibilityLabel("Icono \(ic.replacingOccurrences(of: ".fill", with: ""))")
                            .accessibilityAddTraits(selectedIcon == ic ? .isSelected : [])
                        }
                    }
                }

                HStack(spacing: 8) {
                    Image(systemName: "bolt.circle.fill")
                        .foregroundColor(accentGreen)
                        .font(.system(size: 14))
                        .accessibilityHidden(true)
                    Text("El consumo se detectará automáticamente")
                        .font(.system(size: 12))
                        .foregroundColor(secondaryText(dark))
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accentGreen.opacity(0.07))
                .cornerRadius(12)
                .accessibilityElement(children: .combine)
            }
            .padding(.horizontal)

            VStack(spacing: 10) {
                Button {
                    guard !name.isEmpty && !room.isEmpty else { return }
                    let consumption = defaultConsumption[selectedIcon] ?? 0.1
                    let device = HomeDevice(
                        name: name,
                        icon: selectedIcon,
                        room: room,
                        isOn: true,
                        consumption: consumption
                    )
                    onAdd(device)
                } label: {
                    Text("Agregar dispositivo")
                        .font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                        .frame(maxWidth: .infinity).padding()
                        .background(name.isEmpty || room.isEmpty ? Color.gray.opacity(0.4) : accentBlue)
                        .cornerRadius(16)
                }
                .disabled(name.isEmpty || room.isEmpty)

                Button { showingHomeKit = true } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "homekit").font(.system(size: 14))
                        Text("Conectar con HomeKit")
                            .font(.system(size: 14, weight: .medium))
                    }
                    .foregroundColor(primaryText(dark))
                    .frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(sheetMessageBG(dark)).cornerRadius(16)
                }

                Button { onDismiss() } label: {
                    Text("Cancelar")
                        .font(.system(size: 14))
                        .foregroundColor(secondaryText(dark))
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 32)
        }
        .background(cardBackground(dark))
        .cornerRadius(28)
        .alert("Conectar HomeKit", isPresented: $showingHomeKit) {
            Button("Abrir Ajustes") {
                if let url = URL(string: "App-prefs:root=HOME") {
                    UIApplication.shared.open(url)
                }
            }
            Button("Cancelar", role: .cancel) {}
        } message: {
            Text("Para agregar dispositivos HomeKit:\n1. Abre la app Casa de Apple\n2. Toca el + y escanea el código QR de tu dispositivo\n3. Sigue las instrucciones en pantalla\n\nAlternativamente agrégalo manualmente con el formulario de arriba.")
        }
    }
}

struct HowItWorksRow: View {
    let step: String
    let text: String
    let color: Color
    let dark: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(step)
                .font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                .frame(width: 24, height: 24).background(color).cornerRadius(12)
            Text(text)
                .font(.system(size: 13))
                .foregroundColor(secondaryText(dark))
                .fixedSize(horizontal: false, vertical: true)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Paso \(step): \(text)")
    }
}

struct EnergyBar: View {
    let point: EnergyDataPoint
    let maxValue: Double
    let color: Color
    let dark: Bool

    var body: some View {
        VStack(spacing: 6) {
            GeometryReader { geo in
                // Cambiamos VStack + Spacer por un ZStack anclado abajo
                ZStack(alignment: .bottom) {
                    // Esto fuerza al ZStack a rellenar todo el espacio sin empujar
                    Color.clear
                    
                    RoundedRectangle(cornerRadius: 6)
                        .fill(color)
                        .frame(height: max(4, geo.size.height * (point.value / maxValue)))
                }
            }
            
            Text(point.label)
                .font(.system(size: 9))
                .foregroundColor(secondaryText(dark))
                // Asegura que el texto nunca salte a dos líneas desalineando la barra
                .lineLimit(1)
                .frame(height: 12) // Altura fija para que la base sea idéntica en todos
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(point.label), valor \(String(format: "%.1f", point.value))")
    }
}

struct AIResultSheet: View {
    let message: String
    let recommendedProfile: UserProfile?
    let dark: Bool
    let onApply: (UserProfile) -> Void
    let onDismiss: () -> Void

    var body: some View {
        VStack(spacing: 24) {
            RoundedRectangle(cornerRadius: 3)
                .fill(secondaryText(dark).opacity(0.4))
                .frame(width: 40, height: 5)
                .padding(.top, 12)
                .accessibilityHidden(true)

            VStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color.purple.opacity(dark ? 0.2 : 0.1))
                        .frame(width: 64, height: 64)
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 28))
                        .foregroundColor(Color(red: 0.5, green: 0.2, blue: 0.8))
                }
                .accessibilityHidden(true)
                
                Text("Análisis de IA")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(primaryText(dark))
                    .accessibilityAddTraits(.isHeader)
            }

            Text(message)
                .font(.system(size: 14))
                .foregroundColor(primaryText(dark))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(14)
                .frame(maxWidth: .infinity)
                .background(sheetMessageBG(dark))
                .cornerRadius(14)
                .padding(.horizontal)

            if let rec = recommendedProfile {
                VStack(spacing: 10) {
                    Text("Perfil Recomendado")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(secondaryText(dark))
                        .accessibilityAddTraits(.isHeader)
                        
                    Button { onApply(rec) } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.2)).frame(width: 36, height: 36)
                                Image(systemName: rec.icon).foregroundColor(.white).font(.system(size: 16))
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text(rec.rawValue).font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                                Text(rec.description).font(.system(size: 11)).foregroundColor(.white.opacity(0.8))
                            }
                            Spacer()
                            Text("Aplicar")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(profileColor(rec))
                                .padding(.horizontal, 12).padding(.vertical, 7)
                                .background(Color.white).cornerRadius(12)
                        }
                        .padding(14).background(profileColor(rec)).cornerRadius(18)
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("Aplicar perfil recomendado: \(rec.rawValue). \(rec.description)")
                    .padding(.horizontal)
                }
            }

            Button { onDismiss() } label: {
                Text("Entendido")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(primaryText(dark))
                    .frame(maxWidth: .infinity).padding()
                    .background(sheetButtonBG(dark)).cornerRadius(16)
            }
            .padding(.horizontal).padding(.bottom, 32)
        }
        .background(cardBackground(dark))
        .cornerRadius(28)
    }
}

struct ProfileSheet: View {
    let selected: UserProfile
    let recommended: UserProfile?
    let dark: Bool
    let onSelect: (UserProfile) -> Void
    let onDismiss: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            RoundedRectangle(cornerRadius: 3)
                .fill(secondaryText(dark).opacity(0.4))
                .frame(width: 40, height: 5).padding(.top, 12)
                .accessibilityHidden(true)

            Text("Perfil de Uso")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(primaryText(dark))
                .accessibilityAddTraits(.isHeader)

            Text("El perfil define cómo Tonalli gestiona tus dispositivos automáticamente.")
                .font(.system(size: 13))
                .foregroundColor(secondaryText(dark))
                .multilineTextAlignment(.center).padding(.horizontal)

            VStack(spacing: 12) {
                ForEach(UserProfile.allCases) { profile in
                    Button { onSelect(profile) } label: {
                        HStack(spacing: 14) {
                            ZStack {
                                Circle().fill(profileColor(profile).opacity(dark ? 0.2 : 0.12)).frame(width: 44, height: 44)
                                Image(systemName: profile.icon).foregroundColor(profileColor(profile)).font(.system(size: 20))
                            }
                            VStack(alignment: .leading, spacing: 3) {
                                HStack(spacing: 8) {
                                    Text(profile.rawValue)
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(primaryText(dark))
                                    if recommended == profile {
                                        Text("IA")
                                            .font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                                            .padding(.horizontal, 6).padding(.vertical, 2)
                                            .background(accentBlue).cornerRadius(6)
                                    }
                                }
                                Text(profile.description)
                                    .font(.system(size: 12))
                                    .foregroundColor(secondaryText(dark))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            Spacer()
                            if selected == profile {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(profileColor(profile)).font(.system(size: 22))
                            }
                        }
                        .padding(16)
                        .background(selected == profile ? profileColor(profile).opacity(0.08) : cardBackground(dark))
                        .cornerRadius(18)
                        .overlay(
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(selected == profile ? profileColor(profile).opacity(0.4) : Color.clear, lineWidth: 1.5)
                        )
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("\(profile.rawValue), \(profile.description)\(recommended == profile ? ". Recomendado por Inteligencia Artificial" : "")")
                    .accessibilityAddTraits(selected == profile ? .isSelected : [])
                    .padding(.horizontal)
                }
            }
            .padding(.bottom, 32)
        }
        .background(cardBackground(dark))
        .cornerRadius(28)
    }
}

struct EcoPopup: View {
    let message: String
    let dark: Bool
    let onDismiss: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            RoundedRectangle(cornerRadius: 3)
                .fill(secondaryText(dark).opacity(0.4))
                .frame(width: 40, height: 5).padding(.top, 12)
                .accessibilityHidden(true)

            ZStack {
                Circle().fill(accentBlue.opacity(dark ? 0.2 : 0.1)).frame(width: 64, height: 64)
                Image(systemName: "bolt.circle.fill").font(.system(size: 32)).foregroundColor(accentBlue)
            }
            .accessibilityHidden(true)

            Text("Cambio Detectado")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(primaryText(dark))
                .accessibilityAddTraits(.isHeader)

            Text(message)
                .font(.system(size: 14))
                .foregroundColor(primaryText(dark))
                .multilineTextAlignment(.center)
                .padding(14).frame(maxWidth: .infinity)
                .background(sheetMessageBG(dark)).cornerRadius(14)
                .padding(.horizontal)

            Button { onDismiss() } label: {
                Text("Entendido")
                    .font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                    .frame(maxWidth: .infinity).padding()
                    .background(accentBlue).cornerRadius(16)
            }
            .padding(.horizontal).padding(.bottom, 32)
        }
        .background(cardBackground(dark)).cornerRadius(28)
    }
}

struct EcoLearnOnboardingSheet: View {
    let dark: Bool
    let onAccept: () -> Void
    let onDecline: () -> Void

    var body: some View {
        VStack(spacing: 24) {
            RoundedRectangle(cornerRadius: 3)
                .fill(secondaryText(dark).opacity(0.4))
                .frame(width: 40, height: 5).padding(.top, 12)
                .accessibilityHidden(true)

            ZStack {
                Circle().fill(accentGreen.opacity(dark ? 0.2 : 0.1)).frame(width: 72, height: 72)
                Image(systemName: "leaf.circle.fill").font(.system(size: 36)).foregroundColor(accentGreen)
            }
            .accessibilityHidden(true)

            VStack(spacing: 8) {
                Text("Unirte a EcoLearn")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(primaryText(dark))
                    .accessibilityAddTraits(.isHeader)
                Text("Tu contribución importa")
                    .font(.system(size: 14))
                    .foregroundColor(secondaryText(dark))
            }

            VStack(alignment: .leading, spacing: 14) {
                PermissionRow(
                    icon: "cpu",
                    color: accentBlue,
                    title: "Procesador en segundo plano",
                    detail: "Tonalli solo usará recursos de tu dispositivo cuando esté conectado a carga, en reposo, y con más del 20% de batería. No notarás ninguna diferencia en rendimiento ni batería.",
                    dark: dark
                )
                PermissionRow(
                    icon: "lock.shield.fill",
                    color: accentGreen,
                    title: "Privacidad total garantizada",
                    detail: "Tu información personal, tus datos de uso y los patrones de tu hogar jamás salen de tu dispositivo. Solo compartimos cálculos matemáticos anónimos que no identifican a nadie.",
                    dark: dark
                )
            }
            .padding(16)
            .background(sheetMessageBG(dark))
            .cornerRadius(18)
            .padding(.horizontal)

            VStack(spacing: 12) {
                Button { onAccept() } label: {
                    Text("Unirme y ayudar al planeta")
                        .font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                        .frame(maxWidth: .infinity).padding()
                        .background(accentGreen).cornerRadius(16)
                }
                Button { onDecline() } label: {
                    Text("Ahora no")
                        .font(.system(size: 14))
                        .foregroundColor(secondaryText(dark))
                        .frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(sheetButtonBG(dark)).cornerRadius(16)
                }
            }
            .padding(.horizontal).padding(.bottom, 32)
        }
        .background(cardBackground(dark)).cornerRadius(28)
    }
}

struct PermissionRow: View {
    let icon: String
    let color: Color
    let title: String
    let detail: String
    let dark: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color.opacity(dark ? 0.2 : 0.12))
                    .frame(width: 36, height: 36)
                Image(systemName: icon).foregroundColor(color).font(.system(size: 16))
            }
            .accessibilityHidden(true)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(primaryText(dark))
                Text(detail)
                    .font(.system(size: 12))
                    .foregroundColor(secondaryText(dark))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title). \(detail)")
    }
}
/*

// ============================================================
// MARK: - TONALLI — COMPONENTES REALES (COMENTADOS)
// ============================================================
// Componentes UI con integración real de HomeKit.
// DeviceCard muestra latencia de HomeKit con spinner.
// AddDeviceSheet abre la app Casa para pairing real.
// EnergyChart usa datos reales de CoreData.
// ============================================================

// MARK: - DeviceCard real con HomeKit y latencia visible
// La diferencia con la demo es:
// 1. isLoading muestra un spinner mientras HomeKit responde (200-500ms típico)
// 2. El tap llama a vm.toggleDevice() que escribe en HomeKit real
// 3. Si HomeKit falla (dispositivo offline), el cambio se revierte en UI
// 4. El consumo se actualiza en tiempo real desde el sensor del enchufe
//
// struct DeviceCardReal: View {
//     @Binding var device: HomeDevice
//     let dark: Bool
//     @ObservedObject var vm: TonalliViewModelReal
//     let onDelete: () -> Void
//
//     @State private var isLoading = false  // True mientras HomeKit procesa
//     @State private var showDeleteConfirm = false
//
//     var borderColor: Color { consumptionBorderColor(device.consumption, device.isOn) }
//     var iconColor: Color { device.isOn ? borderColor : secondaryText(dark).opacity(0.4) }
//
//     var body: some View {
//         ZStack {
//             VStack(alignment: .leading, spacing: 0) {
//                 HStack(alignment: .top) {
//
//                     // Spinner visible mientras HomeKit responde
//                     // En la demo no aparece porque no hay latencia real
//                     if isLoading {
//                         ProgressView()
//                             .scaleEffect(0.8)
//                             .frame(width: 24, height: 24)
//                     } else {
//                         Image(systemName: device.icon)
//                             .renderingMode(.template)
//                             .foregroundColor(iconColor)
//                             .font(.system(size: 24))
//                     }
//
//                     Spacer()
//
//                     // Toggle como indicador visual únicamente
//                     // allowsHitTesting(false) previene que intercepte el tap
//                     // El tap en la caja completa maneja el cambio
//                     Toggle("", isOn: $device.isOn)
//                         .labelsHidden()
//                         .scaleEffect(0.75)
//                         .tint(borderColor == Color.clear ? accentBlue : borderColor)
//                         .allowsHitTesting(false)
//                 }
//                 .padding(.bottom, 10)
//
//                 Text(device.name)
//                     .font(.system(size: 14, weight: .semibold))
//                     .foregroundColor(device.isOn ? primaryText(dark) : secondaryText(dark))
//                 Text(device.room)
//                     .font(.system(size: 11))
//                     .foregroundColor(secondaryText(dark))
//                     .padding(.top, 1)
//
//                 Spacer()
//
//                 // Consumo en kW leído directamente de HomeKit
//                 // Se actualiza cada 30 segundos por el timer de consumo
//                 // Solo enchufes con sensor (Eve Energy, Kasa EP25) reportan este valor
//                 if device.isCharging {
//                     HStack(spacing: 4) {
//                         Image(systemName: "bolt.fill").foregroundColor(accentGreen).font(.system(size: 9))
//                         Text("\(device.chargeLevel)%").font(.system(size: 11, weight: .medium)).foregroundColor(accentGreen)
//                     }
//                 } else if device.isOn {
//                     Text(String(format: "%.2f kW", device.consumption))
//                         .font(.system(size: 11)).foregroundColor(secondaryText(dark))
//                 } else {
//                     Text("Apagado").font(.system(size: 11)).foregroundColor(secondaryText(dark).opacity(0.5))
//                 }
//             }
//             .padding(14)
//             .frame(maxWidth: .infinity, alignment: .leading)
//             .background(device.isOn ? borderColor.opacity(dark ? 0.12 : 0.07) : cardBackground(dark))
//             .cornerRadius(20)
//             .shadow(color: .black.opacity(device.isOn ? 0.08 : 0.03), radius: 8, x: 0, y: 4)
//             .overlay(RoundedRectangle(cornerRadius: 20).stroke(borderColor, lineWidth: device.isOn ? 1.8 : 0))
//
//             // Capa transparente de gestos
//             Color.clear
//                 .contentShape(Rectangle())
//                 .gesture(
//                     LongPressGesture(minimumDuration: 0.5)
//                         .onEnded { _ in showDeleteConfirm = true }
//                 )
//                 .simultaneousGesture(
//                     TapGesture().onEnded {
//                         // Cambio optimista: actualizar UI inmediatamente
//                         isLoading = true
//                         withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
//                             device.isOn.toggle()
//                         }
//                         // Enviar comando real a HomeKit
//                         // vm.toggleDevice() escribe en el accesorio físico
//                         // y revierte si HomeKit devuelve error
//                         vm.toggleDevice(device: device)
//
//                         // Ocultar spinner después de tiempo típico de HomeKit
//                         DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
//                             isLoading = false
//                         }
//                     }
//                 )
//         }
//         .alert("¿Eliminar \(device.name)?", isPresented: $showDeleteConfirm) {
//             Button("Eliminar", role: .destructive) { onDelete() }
//             Button("Cancelar", role: .cancel) {}
//         }
//     }
// }

// MARK: - AddDeviceSheet real con HomeKit pairing
// El flujo real de agregar un accesorio HomeKit es:
// 1. Usuario toca "Conectar con HomeKit"
// 2. Se presenta HMAddAccessoryView (iOS 14+) o se abre la app Casa
// 3. Usuario escanea el código QR de 8 dígitos del accesorio
//    (está impreso en el dispositivo o en el manual)
// 4. HomeKit negocia el pairing via Bluetooth o WiFi
//    (protocolo HAP: HomeKit Accessory Protocol)
// 5. El accesorio se agrega al home.accessories
// 6. homeManagerDidUpdateHomes se llama automáticamente
// 7. loadDevicesFromHomeKit() recarga todos los dispositivos
//
// HMAddAccessoryView es la forma nativa de iOS 16+:
//
// struct AddAccessoryViewReal: UIViewControllerRepresentable {
//     let home: HMHome
//
//     func makeUIViewController(context: Context) -> UIViewController {
//         // iOS 16+: vista nativa de pairing de HomeKit
//         // Incluye escáner de QR y guía paso a paso
//         return home.addAndSetupAccessories(completionHandler: { error in
//             if let error = error {
//                 print("Error al agregar accesorio: \(error)")
//             }
//         })
//     }
//
//     func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
// }

// MARK: - EnergyChart real con datos de CoreData
// Las gráficas en producción usan lecturas reales guardadas cada 15 minutos.
// Esto permite ver exactamente qué dispositivo consumió más y cuándo.
// La vista es idéntica a la demo pero los datos son reales.
//
// struct EnergyChartReal: View {
//     // NSFetchRequest obtiene datos de CoreData automáticamente
//     // y actualiza la vista cuando cambian los datos
//     @FetchRequest(
//         entity: EnergyReading.entity(),
//         sortDescriptors: [NSSortDescriptor(keyPath: \EnergyReading.timestamp, ascending: true)],
//         predicate: NSPredicate(
//             format: "timestamp >= %@",
//             Calendar.current.startOfDay(for: Date()) as NSDate
//         )
//     ) var readings: FetchedResults<EnergyReading>
//
//     let dark: Bool
//
//     // Agrupar lecturas por hora y mostrar barras
//     var hourlyData: [EnergyDataPoint] {
//         let calendar = Calendar.current
//         var hourlyKWh: [Int: Double] = [:]
//
//         for reading in readings {
//             let hour = calendar.component(.hour, from: reading.timestamp)
//             // Cada lectura de 15 min = 0.25 hora
//             hourlyKWh[hour, default: 0] += reading.consumption * 0.25
//         }
//
//         return (0..<24).compactMap { hour in
//             guard let kwh = hourlyKWh[hour] else { return nil }
//             return EnergyDataPoint(label: "\(hour)h", value: kwh)
//         }
//     }
//
//     var body: some View {
//         let maxVal = hourlyData.map { $0.value }.max() ?? 1
//         HStack(alignment: .bottom, spacing: 8) {
//             ForEach(hourlyData) { point in
//                 EnergyBar(point: point, maxValue: maxVal, color: accentBlue, dark: dark)
//             }
//         }
//         .frame(height: 120)
//     }
// }

// MARK: - Notificaciones locales reales con categorías y acciones
// En producción las notificaciones tienen botones de acción
// que permiten actuar sin abrir la app (iOS Notification Actions)
//
// Configuración de categorías en AppDelegate:
// let applyAction = UNNotificationAction(
//     identifier: "APPLY_PROFILE",
//     title: "Aplicar perfil",
//     options: .foreground
// )
// let dismissAction = UNNotificationAction(
//     identifier: "DISMISS",
//     title: "Ignorar",
//     options: .destructive
// )
// let profileCategory = UNNotificationCategory(
//     identifier: "PROFILE_SUGGESTION",
//     actions: [applyAction, dismissAction],
//     intentIdentifiers: [],
//     options: []
// )
// UNUserNotificationCenter.current().setNotificationCategories([profileCategory])
//
// Enviar notificación con acciones:
// let content = UNMutableNotificationContent()
// content.title = "Perfil recomendado"
// content.body = "La IA recomienda cambiar a Ahorro máximo"
// content.categoryIdentifier = "PROFILE_SUGGESTION"  // Agrega botones
// content.userInfo = ["profile": "ahorro"]           // Datos para cuando el usuario toca
//
// Manejar respuesta del usuario en UNUserNotificationCenterDelegate:
// func userNotificationCenter(_ center: UNUserNotificationCenter,
//                              didReceive response: UNNotificationResponse) {
//     switch response.actionIdentifier {
//     case "APPLY_PROFILE":
//         let profile = response.notification.request.content.userInfo["profile"] as? String
//         // Aplicar el perfil directamente desde la notificación
//     default: break
//     }
// }

// MARK: - Siri Shortcuts para automatización
// En producción se integran Siri Shortcuts para que el usuario
// pueda decir "Oye Siri, activa modo vacaciones en Tonalli"
// o crear automatizaciones en la app Atajos de Apple.
//
// import Intents
//
// class ActivateVacationModeIntent: INIntent {
//     // Definir en Intents.intentdefinition en Xcode
//     // Agregar capability: Siri
// }
//
// class ActivateVacationModeIntentHandler: NSObject, ActivateVacationModeIntentHandling {
//     func handle(intent: ActivateVacationModeIntent,
//                 completion: @escaping (ActivateVacationModeIntentResponse) -> Void) {
//         // Activar modo vacaciones
//         // Compartir estado con la app via App Groups
//         completion(ActivateVacationModeIntentResponse(code: .success, userActivity: nil))
//     }
// }

// MARK: - Widget de iOS para ver consumo sin abrir la app
// En producción se incluye un Widget Extension que muestra
// el consumo actual en tiempo real en la pantalla de inicio.
//
// import WidgetKit
// import SwiftUI
//
// struct TonalliWidget: Widget {
//     let kind = "TonalliConsumptionWidget"
//
//     var body: some WidgetConfiguration {
//         StaticConfiguration(kind: kind, provider: ConsumptionProvider()) { entry in
//             ConsumptionWidgetView(entry: entry)
//         }
//         .configurationDisplayName("Consumo Tonalli")
//         .description("Ver consumo actual de tu hogar")
//         .supportedFamilies([.systemSmall, .systemMedium])
//     }
// }
//
// struct ConsumptionProvider: TimelineProvider {
//     func getTimeline(in context: Context, completion: @escaping (Timeline<ConsumptionEntry>) -> Void) {
//         // Leer datos de App Groups (compartidos entre app y widget)
//         let sharedDefaults = UserDefaults(suiteName: "group.com.tonalli")
//         let consumption = sharedDefaults?.double(forKey: "current_consumption") ?? 0
//
//         let entry = ConsumptionEntry(date: Date(), consumption: consumption)
//         // Actualizar cada 15 minutos
//         let nextUpdate = Calendar.current.date(byAdding: .minute, value: 15, to: Date())!
//         let timeline = Timeline(entries: [entry], policy: .after(nextUpdate))
//         completion(timeline)
//     }
//
//     func placeholder(in context: Context) -> ConsumptionEntry {
//         ConsumptionEntry(date: Date(), consumption: 1.43)
//     }
//
//     func getSnapshot(in context: Context, completion: @escaping (ConsumptionEntry) -> Void) {
//         completion(ConsumptionEntry(date: Date(), consumption: 1.43))
//     }
// }

*/
