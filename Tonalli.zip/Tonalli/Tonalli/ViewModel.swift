import SwiftUI
import Combine
import UserNotifications

class TonalliViewModel: ObservableObject {

    @Published var isDarkMode = false

    @Published var devices: [HomeDevice] = [
        HomeDevice(name: "Sala", icon: "lightbulb.fill", room: "Sala", isOn: true, consumption: 0.06),
        HomeDevice(name: "Aire acondicionado", icon: "snowflake", room: "Recamara", isOn: true, consumption: 1.2),
        HomeDevice(name: "TV", icon: "tv.fill", room: "Sala", isOn: false, consumption: 0.15),
        HomeDevice(name: "iPhone", icon: "iphone", room: "Recamara", isOn: true, consumption: 0.02, isCharging: true, chargeLevel: 87),
        HomeDevice(name: "Lavadora", icon: "washer.fill", room: "Lavanderia", isOn: false, consumption: 0.5),
        HomeDevice(name: "Refrigerador", icon: "refrigerator.fill", room: "Cocina", isOn: true, consumption: 0.15),
    ]

    private var preVacationState: [String: Bool] = [:]

    @Published var vacationMode = false
    @Published var ecoMode = false
    @Published var showEcoOnboarding = false
    @Published var aiLearningEnabled = false
    @Published var currentProfile = "Balanceado"
    @Published var selectedUserProfile: UserProfile = .balanceado
    @Published var recommendedProfile: UserProfile? = nil
    @Published var showProfileSheet = false
    @Published var showAIResultSheet = false
    @Published var aiResultMessage = ""
    @Published var showEcoPopup = false
    @Published var ecoPopupMessage = ""
    @Published var dailySavingsKWh: Double = 2.34
    @Published var selectedTab = 0

    @Published var myContributions = 0
    @Published var myCO2Saved = 0.0
    @Published var globalRound = 0
    @Published var activeUsers = 3847
    @Published var isTraining = false
    @Published var leaderboard: [LeaderEntry] = []

    @Published var energyDataDay: [EnergyDataPoint] = [
        EnergyDataPoint(label: "00h", value: 0.3),
        EnergyDataPoint(label: "04h", value: 0.2),
        EnergyDataPoint(label: "08h", value: 0.8),
        EnergyDataPoint(label: "12h", value: 1.4),
        EnergyDataPoint(label: "16h", value: 1.1),
        EnergyDataPoint(label: "20h", value: 1.6),
        EnergyDataPoint(label: "23h", value: 0.9),
    ]

    @Published var energyDataWeek: [EnergyDataPoint] = [
        EnergyDataPoint(label: "Lun", value: 8.2),
        EnergyDataPoint(label: "Mar", value: 7.5),
        EnergyDataPoint(label: "Mie", value: 9.1),
        EnergyDataPoint(label: "Jue", value: 6.8),
        EnergyDataPoint(label: "Vie", value: 10.2),
        EnergyDataPoint(label: "Sab", value: 11.5),
        EnergyDataPoint(label: "Hoy", value: 17.16),
    ]

    @Published var energyDataMonth: [EnergyDataPoint] = [
        EnergyDataPoint(label: "S1", value: 58.0),
        EnergyDataPoint(label: "S2", value: 63.5),
        EnergyDataPoint(label: "S3", value: 55.2),
        EnergyDataPoint(label: "S4", value: 71.0),
    ]

    private var w0: Double = 0.0
    private var w1: Double = 0.1
    private var w2: Double = 0.3
    private let lr: Double = 0.01
    private var trainingHistory: [TrainingPoint] = []
    private var previousAvgConsumption: Double = 0.0
    private var roundsSinceLastNotification = 0
    private var sentNotifications: Set<String> = []
    private var aiSheetPendingDismiss = false
    var deviceSuggestionSent = false

    let serverURL = "http://192.168.150.149:8000"
    let userID = UIDevice.current.identifierForVendor?.uuidString ?? "user-1"
    let userName = UIDevice.current.name
    private var trainingTimer: Timer?
    private var learningTimer: Timer?

    var totalConsumption: Double {
        max(0, devices.filter { $0.isOn }.reduce(0) { $0 + $1.consumption })
    }

    var activeDevices: Int {
        devices.filter { $0.isOn }.count
    }

    var estimatedDailyCost: Double {
        max(0, totalConsumption * 24 * 1.5)
    }

    var dailySavingsPesos: Double {
        max(0, dailySavingsKWh * 1.5)
    }

    init() {
        requestNotificationPermission()
        seedTrainingData()
        fetchStatus()
        fetchLeaderboard()
        previousAvgConsumption = totalConsumption
    }

    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    func sendNotification(notifID: String, title: String, body: String) {
        guard !sentNotifications.contains(notifID) else { return }
        sentNotifications.insert(notifID)
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: notifID, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    func resetNotification(notifID: String) {
        sentNotifications.remove(notifID)
    }

    func toggleAILearning() {
        aiLearningEnabled.toggle()
        if aiLearningEnabled {
            deviceSuggestionSent = false
            aiSheetPendingDismiss = false
            resetNotification(notifID: "ai_suggestion")
            resetNotification(notifID: "ai_devices")
            learningTimer = Timer.scheduledTimer(withTimeInterval: 60.0, repeats: true) { _ in
                guard !self.aiSheetPendingDismiss else { return }
                self.runAIAnalysis()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                self.runAIAnalysis()
            }
        } else {
            learningTimer?.invalidate()
            learningTimer = nil
            deviceSuggestionSent = false
            aiSheetPendingDismiss = false
            showAIResultSheet = false
            resetNotification(notifID: "ai_suggestion")
            resetNotification(notifID: "ai_devices")
        }
    }

    func computeDowngradeProfile() -> UserProfile? {
        switch selectedUserProfile {
        case .confort: return Int.random(in: 0...1) == 0 ? .balanceado : .ahorro
        case .balanceado: return .ahorro
        case .ahorro: return nil
        }
    }

    func runAIAnalysis() {
        guard aiLearningEnabled && !aiSheetPendingDismiss && !showAIResultSheet else { return }
        DispatchQueue.global(qos: .background).asyncAfter(deadline: .now() + 1.5) {
            self.learnFromCurrentState()
            let result = self.smartRecommendation()
            let rec = self.computeDowngradeProfile()
            DispatchQueue.main.async {
                guard !self.showAIResultSheet && !self.aiSheetPendingDismiss else { return }
                self.aiResultMessage = result
                self.recommendedProfile = rec
                self.aiSheetPendingDismiss = true
                self.showAIResultSheet = true
            }
        }
    }

    func dismissAISheet() {
        showAIResultSheet = false
        aiSheetPendingDismiss = false
        let deviceMsg = smartRecommendation()
        if !deviceMsg.contains("optimizado") {
            sendNotification(
                notifID: "ai_devices",
                title: "Sugerencia de ahorro",
                body: deviceMsg
            )
        }
        resetNotification(notifID: "ai_suggestion")
    }

    func applyFromSheet(_ profile: UserProfile) {
        applyProfile(profile)
        showAIResultSheet = false
        aiSheetPendingDismiss = false
        resetNotification(notifID: "ai_suggestion")
        resetNotification(notifID: "ai_devices")
    }

    func checkForPatternChange() {
        guard !showEcoPopup else { return }
        let currentAvg = totalConsumption
        let delta = abs(currentAvg - previousAvgConsumption)
        roundsSinceLastNotification += 1
        if delta > 0.3 && roundsSinceLastNotification > 15 {
            let direction = currentAvg > previousAvgConsumption ? "aumento" : "disminuyo"
            let msg = "El consumo de tu hogar \(direction) \(String(format: "%.1f", delta * 100))%. El modelo esta actualizando tu perfil."
            DispatchQueue.main.async {
                self.ecoPopupMessage = msg
                self.showEcoPopup = true
            }
            roundsSinceLastNotification = 0
            previousAvgConsumption = currentAvg
        }
    }

    func dismissEcoPopup() {
        showEcoPopup = false
    }

    func computeRecommendedProfile() -> UserProfile {
        let hour = Double(Calendar.current.component(.hour, from: Date()))
        let avg = totalConsumption
        let count = activeDevices
        if (hour >= 22 || hour < 7) && avg > 0.5 { return .ahorro }
        if count <= 2 || avg < 0.3 { return .ahorro }
        if avg > 1.0 { return .confort }
        return .balanceado
    }

    func applyProfile(_ profile: UserProfile) {
        selectedUserProfile = profile
        recommendedProfile = nil
        currentProfile = profile.rawValue
        for i in devices.indices {
            devices[i].isOn = profile.devicesOn.contains(devices[i].name)
        }
        dailySavingsKWh = profile == .ahorro ? 4.2 : profile == .balanceado ? 2.34 : 0.8
        showProfileSheet = false
    }

    func toggleVacationMode() {
        vacationMode.toggle()
        if vacationMode {
            for device in devices {
                preVacationState[device.name] = device.isOn
            }
            for i in devices.indices where devices[i].name != "Refrigerador" {
                devices[i].isOn = false
            }
            currentProfile = "Vacaciones"
        } else {
            for i in devices.indices {
                if let prev = preVacationState[devices[i].name] {
                    devices[i].isOn = prev
                }
            }
            preVacationState = [:]
            currentProfile = selectedUserProfile.rawValue
        }
    }

    private func seedTrainingData() {
        let seed: [(Double, Double, Double)] = [
            (2, 1.2, 1), (3, 1.1, 1), (14, 0.06, 0),
            (22, 1.3, 1), (23, 1.2, 1), (10, 0.5, 0),
            (1, 0.8, 1), (18, 1.5, 1), (9, 0.3, 0),
            (20, 1.1, 0), (7, 0.4, 0), (0, 1.0, 1)
        ]
        trainingHistory = seed.map { TrainingPoint(hour: $0.0, consumption: $0.1, label: $0.2) }
        for _ in 0..<50 { trainStep() }
    }

    private func sigmoid(_ x: Double) -> Double {
        1.0 / (1.0 + exp(-x))
    }

    private func predict(hour: Double, consumption: Double) -> Double {
        sigmoid(w0 + w1 * hour + w2 * consumption)
    }

    private func trainStep() {
        guard !trainingHistory.isEmpty else { return }
        var dw0 = 0.0, dw1 = 0.0, dw2 = 0.0
        for point in trainingHistory {
            let pred = predict(hour: point.hour, consumption: point.consumption)
            let err = pred - point.label
            dw0 += err
            dw1 += err * point.hour
            dw2 += err * point.consumption
        }
        let n = Double(trainingHistory.count)
        w0 -= lr * dw0 / n
        w1 -= lr * dw1 / n
        w2 -= lr * dw2 / n
    }

    func learnFromCurrentState() {
        let hour = Double(Calendar.current.component(.hour, from: Date()))
        for device in devices {
            let label: Double = (hour < 6 || hour > 23) && device.consumption > 0.5 ? 1.0 : 0.0
            trainingHistory.append(TrainingPoint(hour: hour, consumption: device.consumption, label: label))
        }
        for _ in 0..<10 { trainStep() }
        checkForPatternChange()
    }

    func smartRecommendation() -> String {
        let hour = Double(Calendar.current.component(.hour, from: Date()))
        var recs: [String] = []
        for device in devices where device.isOn {
            let score = predict(hour: hour, consumption: device.consumption)
            if score > 0.65 {
                recs.append("\(device.name) (\(String(format: "%.0f%%", score * 100)) prob.)")
            }
        }
        if recs.isEmpty {
            return "Todo esta optimizado para este horario. Tu hogar consume de manera eficiente ahora mismo."
        }
        return "Conviene apagar: \(recs.joined(separator: ", ")). Ahorro estimado ~$\(String(format: "%.0f", max(0, totalConsumption * 0.5 * 1.5))) pesos."
    }

    func currentModelWeights() -> [Double] { [w0, w1, w2] }

    func requestEcoMode() {
        showEcoOnboarding = true
    }

    func acceptEcoMode() {
        showEcoOnboarding = false
        ecoMode = true
        currentProfile = "EcoLearn activo"
        sendNotification(
            notifID: "ecolearn_welcome",
            title: "Bienvenido a EcoLearn",
            body: "Gracias por unirte. Tus datos son completamente privados. Solo actuaremos mientras tu telefono este cargando con mas de 20% de bateria."
        )
        startFederatedTraining()
    }

    func declineEcoMode() {
        showEcoOnboarding = false
        ecoMode = false
    }

    func disableEcoMode() {
        ecoMode = false
        trainingTimer?.invalidate()
        trainingTimer = nil
        isTraining = false
        currentProfile = selectedUserProfile.rawValue
        resetNotification(notifID: "ecolearn_welcome")
    }

    private func startFederatedTraining() {
        trainingTimer = Timer.scheduledTimer(withTimeInterval: 8.0, repeats: true) { _ in
            self.runFederatedRound()
        }
        runFederatedRound()
    }

    private func runFederatedRound() {
        guard ecoMode else { return }
        isTraining = true
        DispatchQueue.global(qos: .background).asyncAfter(deadline: .now() + 2) {
            self.learnFromCurrentState()
            let weights = self.currentModelWeights()
            self.submitUpdate(weights: weights)
        }
    }

    private func submitUpdate(weights: [Double]) {
        guard let url = URL(string: "\(serverURL)/submit_update") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "user_id": userID,
            "name": userName,
            "weights": weights,
            "num_samples": trainingHistory.count
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: request) { _, _, _ in
            DispatchQueue.main.async {
                self.isTraining = false
                self.myContributions += 1
                self.myCO2Saved += 0.007 * 0.233
                self.fetchStatus()
                self.fetchLeaderboard()
            }
        }.resume()
    }

    func fetchStatus() {
        guard let url = URL(string: "\(serverURL)/status") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
            DispatchQueue.main.async {
                self.globalRound = json["round"] as? Int ?? self.globalRound
                let serverUsers = json["active_users"] as? Int ?? 0
                self.activeUsers = max(3847, 3847 + serverUsers)
            }
        }.resume()
    }

    func fetchLeaderboard() {
        guard let url = URL(string: "\(serverURL)/leaderboard") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let board = json["leaderboard"] as? [[String: Any]] else { return }
            DispatchQueue.main.async {
                self.leaderboard = board.prefix(5).map {
                    LeaderEntry(
                        name: $0["name"] as? String ?? "Usuario",
                        co2: $0["co2_saved_kg"] as? Double ?? 0,
                        contributions: $0["contributions"] as? Int ?? 0
                    )
                }
            }
        }.resume()
    }
}



/*

// ============================================================
// MARK: - TONALLI — VIEWMODEL REAL (COMENTADO PARA REFERENCIA)
// ============================================================
// Implementación real completa del ViewModel de producción.
// Incluye HomeKit, red neuronal con backpropagation,
// Federated Learning real, BGProcessingTask, CoreMotion,
// WeatherKit, CoreData y CloudKit.
//
// Para activar en producción:
// 1. Quitar todos los /* y */ de este bloque
// 2. Reemplazar TonalliViewModel por esta implementación
// 3. Activar entitlements en Xcode:
//    Signing & Capabilities → +
//    → HomeKit
//    → Background Modes (fetch + processing)
//    → iCloud → CloudKit
// 4. Agregar a Info.plist:
//    NSHomeKitUsageDescription
//    NSLocationWhenInUseUsageDescription
//    NSMotionUsageDescription
//    BGTaskSchedulerPermittedIdentifiers: [com.tonalli.training]
// ============================================================

import HomeKit
import BackgroundTasks
import CoreMotion
import CoreData

// MARK: - ViewModel real hereda de NSObject para ser HMHomeManagerDelegate
// NSObject es necesario porque los delegates de HomeKit
// requieren compatibilidad con Objective-C runtime
//
// class TonalliViewModelReal: NSObject, ObservableObject, HMHomeManagerDelegate {
//
//     // MARK: Estado publicado de UI — igual que la demo
//     @Published var isDarkMode = false
//     @Published var devices: [HomeDevice] = []
//     @Published var vacationMode = false
//     @Published var ecoMode = false
//     @Published var showEcoOnboarding = false
//     @Published var aiLearningEnabled = false
//     @Published var currentProfile = "Balanceado"
//     @Published var selectedUserProfile: UserProfile = .balanceado
//     @Published var recommendedProfile: UserProfile? = nil
//     @Published var showProfileSheet = false
//     @Published var showAIResultSheet = false
//     @Published var aiResultMessage = ""
//     @Published var showEcoPopup = false
//     @Published var ecoPopupMessage = ""
//     @Published var dailySavingsKWh: Double = 0.0
//     @Published var myContributions = 0
//     @Published var myCO2Saved = 0.0
//     @Published var globalRound = 0
//     @Published var activeUsers = 0
//     @Published var isTraining = false
//     @Published var leaderboard: [LeaderEntry] = []
//     @Published var energyDataDay: [EnergyDataPoint] = []
//     @Published var energyDataWeek: [EnergyDataPoint] = []
//     @Published var energyDataMonth: [EnergyDataPoint] = []
//
//     // MARK: - HomeKit
//     // HMHomeManager es el punto de entrada a todo el ecosistema HomeKit.
//     // Al crear la instancia, iOS carga automáticamente todos los hogares
//     // configurados por el usuario en la app Casa.
//     // homeManagerDidUpdateHomes se llama cuando los datos están listos.
//     private let homeManager = HMHomeManager()
//     private var primaryHome: HMHome?
//
//     // MARK: - Red neuronal real (113 parámetros)
//     // Arquitectura: Input(5) → Dense(16, ReLU) → Dense(1, Sigmoid)
//     // Reemplaza la regresión logística de la demo
//     private var neuralNet = NeuralNetwork()
//
//     // MARK: - Historial de entrenamiento
//     // Se acumula a lo largo del tiempo con datos reales
//     // Máximo 500 puntos para no sobrecargar memoria
//     private var trainingHistory: [TrainingPoint] = []
//
//     // MARK: - CoreMotion para detectar presencia en casa
//     // El acelerómetro del iPhone detecta si el usuario está
//     // caminando/corriendo (fuera de casa) o quieto (en casa)
//     private let motionManager = CMMotionActivityManager()
//     private var isAtHome = true
//
//     // MARK: - Estado de consumo previo para detectar cambios
//     private var previousAvgConsumption: Double = 0.0
//     private var roundsSinceLastCheck = 0
//
//     // MARK: - Control estricto de notificaciones
//     // Cada tipo de notificación solo se manda UNA vez por sesión
//     // El ID único previene duplicados aunque el timer se repita
//     private var sentNotifications: Set<String> = []
//     private var aiSheetPendingDismiss = false
//     var deviceSuggestionSent = false
//
//     // MARK: - Estado de vacaciones
//     private var preVacationState: [String: Bool] = [:]
//
//     // MARK: - Timers de background
//     private var consumptionTimer: Timer?    // Lectura HomeKit cada 30s
//     private var dataCollectionTimer: Timer? // Datos de entrenamiento cada 15min
//     private var federatedTimer: Timer?      // Envío de pesos federados
//     private var learningTimer: Timer?       // Análisis de IA periódico
//
//     // MARK: - URL del servidor Federated Learning
//     // En producción: HTTPS con JWT auth y certificado SSL
//     // Ejemplo: https://api.tonalli.mx/v1
//     let serverURL = "https://api.tonalli.mx"
//
//     // MARK: - Identificador anónimo del dispositivo
//     // identifierForVendor es único por app+dispositivo
//     // Se resetea si el usuario desinstala y reinstala la app
//     // Nunca contiene información personal identificable
//     let userID = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
//     let userName = UIDevice.current.name
//
//     // MARK: - CoreData context inyectado desde el environment
//     // En producción se inyecta con @Environment(\.managedObjectContext)
//     // let context: NSManagedObjectContext
//
//     // MARK: - Inicialización
//     override init() {
//         super.init()
//
//         // Configurar HomeKit delegate
//         // homeManagerDidUpdateHomes se llama async cuando los datos están listos
//         homeManager.delegate = self
//
//         // Activar monitoreo de batería para condiciones de EcoLearn
//         // Necesario para saber si está cargando y nivel de batería
//         UIDevice.current.isBatteryMonitoringEnabled = true
//
//         // Observar cambios de nivel de batería
//         // Notifica cuando llega al 100% o baja del 20%
//         NotificationCenter.default.addObserver(
//             self,
//             selector: #selector(batteryLevelChanged),
//             name: UIDevice.batteryLevelDidChangeNotification,
//             object: nil
//         )
//
//         // Observar cambios de estado de carga
//         // Notifica cuando se conecta o desconecta el cargador
//         NotificationCenter.default.addObserver(
//             self,
//             selector: #selector(batteryStateChanged),
//             name: UIDevice.batteryStateDidChangeNotification,
//             object: nil
//         )
//
//         // Solicitar permisos de notificación al sistema
//         requestNotificationPermission()
//
//         // Iniciar detección de presencia con CoreMotion
//         // Usa el acelerómetro para detectar si el usuario está en movimiento
//         startPresenceDetection()
//
//         // Intentar cargar pesos guardados de sesiones anteriores
//         // Si no hay, la red neuronal se inicializa con pesos aleatorios
//         loadSavedWeights()
//
//         // Cargar historial de energía de CoreData
//         // Llena energyDataDay, energyDataWeek, energyDataMonth
//         loadEnergyHistoryFromCoreData()
//
//         // Sincronizar con el servidor de Federated Learning
//         fetchStatus()
//         fetchLeaderboard()
//     }
//
//     // MARK: - HMHomeManagerDelegate
//     // Se llama cuando HomeKit termina de cargar todos los hogares
//     // del usuario. Puede tardar varios segundos la primera vez.
//     func homeManagerDidUpdateHomes(_ manager: HMHomeManager) {
//         // Seleccionar el hogar principal del usuario
//         primaryHome = manager.primaryHome
//
//         guard let home = primaryHome else {
//             // El usuario no tiene HomeKit configurado
//             // Mostrar onboarding para configurarlo
//             print("Sin hogar HomeKit. Mostrar instrucciones de configuración.")
//             return
//         }
//
//         // Convertir todos los HMAccessory a nuestros HomeDevice
//         loadDevicesFromHomeKit(home: home)
//
//         // Suscribirse a cambios en tiempo real de cada accesorio
//         // homeAccessory(_:service:didUpdateValueFor:) se llamará
//         // cuando alguien encienda/apague un dispositivo físicamente
//         for accessory in home.accessories {
//             accessory.delegate = self
//         }
//
//         // Iniciar lectura periódica de consumo energético
//         startConsumptionReading()
//     }
//
//     // MARK: - Cargar dispositivos reales desde HomeKit
//     private func loadDevicesFromHomeKit(home: HMHome) {
//         DispatchQueue.main.async {
//             // Filtrar accesorios que no tienen características útiles
//             self.devices = home.accessories.compactMap { accessory in
//                 self.homeDeviceFrom(accessory: accessory)
//             }
//             self.previousAvgConsumption = self.totalConsumption
//         }
//     }
//
//     // MARK: - Convertir HMAccessory a HomeDevice
//     // Lee el estado actual y consumo del accesorio
//     private func homeDeviceFrom(accessory: HMAccessory) -> HomeDevice? {
//         var isOn = false
//         var consumption = 0.0
//
//         for service in accessory.services {
//             for characteristic in service.characteristics {
//
//                 // HMCharacteristicTypePowerState: estado encendido/apagado
//                 // Tipo: Bool — true = encendido, false = apagado
//                 if characteristic.characteristicType == HMCharacteristicTypePowerState {
//                     isOn = characteristic.value as? Bool ?? false
//                 }
//
//                 // Característica de potencia activa (kW medido por sensor físico)
//                 // UUID estándar HAP (HomeKit Accessory Protocol): 00000119-0000-1000-8000-0026BB765291
//                 // Soportado por: Eve Energy, Kasa EP25, Meross MSS310, Shelly 1PM
//                 // El valor viene en Watts — convertir a kW dividiendo entre 1000
//                 if characteristic.characteristicType == "00000119-0000-1000-8000-0026BB765291" {
//                     let watts = characteristic.value as? Double ?? 0.0
//                     consumption = watts / 1000.0
//                 }
//             }
//         }
//
//         return HomeDevice(
//             id: accessory.uniqueIdentifier,
//             name: accessory.name,
//             icon: iconForAccessory(accessory),
//             room: accessory.room?.name ?? "Sin habitación",
//             isOn: isOn,
//             consumption: consumption,
//             isCharging: false,
//             chargeLevel: 100,
//             hmIdentifier: accessory.uniqueIdentifier.uuidString
//         )
//     }
//
//     // MARK: - Inferir icono según categoría HomeKit
//     // HMAccessoryCategoryType mapea al tipo físico del accesorio
//     private func iconForAccessory(_ accessory: HMAccessory) -> String {
//         switch accessory.category.categoryType {
//         case .lightbulb:       return "lightbulb.fill"
//         case .fan:             return "fan.fill"
//         case .thermostat:      return "thermometer"
//         case .airConditioner:  return "snowflake"
//         case .television:      return "tv.fill"
//         case .outlet:          return "powerplug.fill"
//         case .switch:          return "light.recessed.fill"
//         case .washingMachine:  return "washer.fill"
//         case .refrigerator:    return "refrigerator.fill"
//         case .airPurifier:     return "wind"
//         case .oven:            return "oven.fill"     // iOS 16.1+
//         default:               return "bolt.fill"
//         }
//     }
//
//     // MARK: - Encender/apagar dispositivo real via HomeKit
//     // Se usa cambio optimista: actualizar UI inmediatamente
//     // y revertir si HomeKit devuelve error
//     func toggleDevice(device: HomeDevice) {
//         guard let home = primaryHome,
//               let accessory = home.accessories.first(where: {
//                   $0.uniqueIdentifier.uuidString == device.hmIdentifier
//               })
//         else { return }
//
//         let newState = !device.isOn
//
//         for service in accessory.services {
//             for characteristic in service.characteristics {
//                 if characteristic.characteristicType == HMCharacteristicTypePowerState {
//                     characteristic.writeValue(newState) { [weak self] error in
//                         DispatchQueue.main.async {
//                             if let error = error {
//                                 // Revertir cambio optimista si HomeKit falló
//                                 // Puede fallar si el dispositivo está offline
//                                 print("Error HomeKit: \(error.localizedDescription)")
//                                 if let idx = self?.devices.firstIndex(where: { $0.id == device.id }) {
//                                     self?.devices[idx].isOn = !newState
//                                 }
//                             } else {
//                                 // Guardar lectura exitosa en CoreData
//                                 if let idx = self?.devices.firstIndex(where: { $0.id == device.id }) {
//                                     self?.recordEnergyReading(device: self!.devices[idx])
//                                     self?.updateDailySavings()
//                                 }
//                             }
//                         }
//                     }
//                 }
//             }
//         }
//     }
//
//     // MARK: - HMAccessoryDelegate
//     // Actualización en tiempo real cuando el dispositivo cambia
//     // físicamente (alguien lo apaga desde el interruptor de pared)
//     func accessory(_ accessory: HMAccessory,
//                    service: HMService,
//                    didUpdateValueFor characteristic: HMCharacteristic) {
//
//         // Actualizar estado de encendido/apagado
//         if characteristic.characteristicType == HMCharacteristicTypePowerState,
//            let isOn = characteristic.value as? Bool,
//            let idx = devices.firstIndex(where: { $0.name == accessory.name }) {
//             DispatchQueue.main.async {
//                 self.devices[idx].isOn = isOn
//                 self.recordEnergyReading(device: self.devices[idx])
//                 self.updateDailySavings()
//             }
//         }
//
//         // Actualizar consumo en tiempo real si el sensor reporta nuevo valor
//         if characteristic.characteristicType == "00000119-0000-1000-8000-0026BB765291",
//            let watts = characteristic.value as? Double,
//            let idx = devices.firstIndex(where: { $0.name == accessory.name }) {
//             DispatchQueue.main.async {
//                 self.devices[idx].consumption = watts / 1000.0
//                 self.updateDailySavings()
//             }
//         }
//     }
//
//     // MARK: - Lectura periódica de consumo HomeKit
//     // Se llama cada 30 segundos para mantener valores actualizados
//     // Algunos enchufes inteligentes solo reportan cambios grandes,
//     // por lo que se hace polling para tener valores frescos
//     private func startConsumptionReading() {
//         consumptionTimer = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { [weak self] _ in
//             self?.readAllConsumptions()
//         }
//         readAllConsumptions()
//     }
//
//     private func readAllConsumptions() {
//         guard let home = primaryHome else { return }
//
//         for accessory in home.accessories {
//             for service in accessory.services {
//                 for characteristic in service.characteristics {
//                     if characteristic.characteristicType == "00000119-0000-1000-8000-0026BB765291" {
//                         characteristic.readValue { [weak self] error in
//                             guard error == nil,
//                                   let watts = characteristic.value as? Double,
//                                   let idx = self?.devices.firstIndex(where: {
//                                       $0.name == accessory.name
//                                   })
//                             else { return }
//                             DispatchQueue.main.async {
//                                 self?.devices[idx].consumption = watts / 1000.0
//                             }
//                         }
//                     }
//                 }
//             }
//         }
//     }
//
//     // MARK: - CoreData: guardar lectura de energía
//     // Se guarda cada vez que un dispositivo cambia estado
//     // y cada 15 minutos para el historial continuo
//     private func recordEnergyReading(device: HomeDevice) {
//         let context = PersistenceController.shared.container.viewContext
//         let reading = EnergyReading(context: context)
//         reading.timestamp = Date()
//         reading.consumption = device.consumption
//         reading.deviceName = device.name
//         reading.isOn = device.isOn
//         reading.room = device.room
//         try? context.save()
//     }
//
//     // MARK: - CoreData: cargar historial para las gráficas
//     // Agrupa las lecturas por hora/día/semana para mostrar en UI
//     private func loadEnergyHistoryFromCoreData() {
//         let context = PersistenceController.shared.container.viewContext
//         let calendar = Calendar.current
//         let now = Date()
//
//         // --- Datos del día actual agrupados por hora ---
//         let startOfDay = calendar.startOfDay(for: now)
//         let dayRequest: NSFetchRequest<EnergyReading> = EnergyReading.fetchRequest()
//         dayRequest.predicate = NSPredicate(format: "timestamp >= %@", startOfDay as NSDate)
//         dayRequest.sortDescriptors = [NSSortDescriptor(keyPath: \EnergyReading.timestamp, ascending: true)]
//
//         if let dayReadings = try? context.fetch(dayRequest) {
//             energyDataDay = groupReadingsByHour(dayReadings)
//         }
//
//         // --- Datos de la semana agrupados por día ---
//         let startOfWeek = calendar.date(byAdding: .day, value: -6, to: startOfDay)!
//         let weekRequest: NSFetchRequest<EnergyReading> = EnergyReading.fetchRequest()
//         weekRequest.predicate = NSPredicate(format: "timestamp >= %@", startOfWeek as NSDate)
//
//         if let weekReadings = try? context.fetch(weekRequest) {
//             energyDataWeek = groupReadingsByDay(weekReadings)
//         }
//
//         // --- Datos del mes agrupados por semana ---
//         let startOfMonth = calendar.date(byAdding: .month, value: -1, to: startOfDay)!
//         let monthRequest: NSFetchRequest<EnergyReading> = EnergyReading.fetchRequest()
//         monthRequest.predicate = NSPredicate(format: "timestamp >= %@", startOfMonth as NSDate)
//
//         if let monthReadings = try? context.fetch(monthRequest) {
//             energyDataMonth = groupReadingsByWeek(monthReadings)
//         }
//     }
//
//     // Agrupar lecturas por hora y calcular kWh promedio
//     private func groupReadingsByHour(_ readings: [EnergyReading]) -> [EnergyDataPoint] {
//         let calendar = Calendar.current
//         var hourlyData: [Int: [Double]] = [:]
//
//         for reading in readings {
//             let hour = calendar.component(.hour, from: reading.timestamp)
//             hourlyData[hour, default: []].append(reading.consumption)
//         }
//
//         return (0..<24).compactMap { hour in
//             guard let values = hourlyData[hour], !values.isEmpty else { return nil }
//             let avgKW = values.reduce(0, +) / Double(values.count)
//             let kWh = avgKW * 0.25 // Promedio durante 15 minutos = kWh
//             return EnergyDataPoint(label: "\(hour)h", value: kWh)
//         }
//     }
//
//     // Agrupar lecturas por día y calcular kWh totales
//     private func groupReadingsByDay(_ readings: [EnergyReading]) -> [EnergyDataPoint] {
//         let calendar = Calendar.current
//         let dayNames = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"]
//         var dailyData: [Int: [Double]] = [:]
//
//         for reading in readings {
//             let weekday = calendar.component(.weekday, from: reading.timestamp)
//             dailyData[weekday, default: []].append(reading.consumption)
//         }
//
//         return (1...7).compactMap { weekday in
//             guard let values = dailyData[weekday], !values.isEmpty else { return nil }
//             let totalKWh = values.reduce(0, +) * 0.5 // Cada lectura ~30min
//             return EnergyDataPoint(label: dayNames[weekday - 1], value: totalKWh)
//         }
//     }
//
//     // Agrupar lecturas por semana y calcular kWh totales
//     private func groupReadingsByWeek(_ readings: [EnergyReading]) -> [EnergyDataPoint] {
//         let calendar = Calendar.current
//         var weeklyData: [Int: [Double]] = [:]
//
//         for reading in readings {
//             let week = calendar.component(.weekOfMonth, from: reading.timestamp)
//             weeklyData[week, default: []].append(reading.consumption)
//         }
//
//         return weeklyData.keys.sorted().enumerated().map { (idx, week) in
//             let values = weeklyData[week]!
//             let totalKWh = values.reduce(0, +) * 0.5
//             return EnergyDataPoint(label: "S\(idx + 1)", value: totalKWh)
//         }
//     }
//
//     // MARK: - Detección de presencia con CoreMotion
//     // Usa el acelerómetro del iPhone para determinar si el usuario
//     // está en movimiento (fuera de casa) o quieto (en casa)
//     // Combinado con geofencing de CoreLocation sería más preciso
//     private func startPresenceDetection() {
//         guard CMMotionActivityManager.isActivityAvailable() else { return }
//
//         motionManager.startActivityUpdates(to: .main) { [weak self] activity in
//             guard let activity = activity else { return }
//             // Si está caminando o corriendo → probablemente fuera de casa
//             self?.isAtHome = !(activity.walking || activity.running || activity.cycling)
//         }
//     }
//
//     // MARK: - Temperatura real con WeatherKit (iOS 16+)
//     // Requiere:
//     // 1. Capabilities → WeatherKit
//     // 2. Descripción en Info.plist: NSLocationWhenInUseUsageDescription
//     // 3. import WeatherKit + import CoreLocation
//     //
//     // @MainActor
//     // func fetchCurrentTemperature() async -> Double {
//     //     let locationManager = CLLocationManager()
//     //     locationManager.requestWhenInUseAuthorization()
//     //     guard let location = locationManager.location else { return 25.0 }
//     //     let service = WeatherService.shared
//     //     do {
//     //         let weather = try await service.weather(for: location)
//     //         return weather.currentWeather.temperature.converted(to: .celsius).value
//     //     } catch { return 25.0 }
//     // }
//
//     // MARK: - Recolección de datos de entrenamiento reales
//     // Se llama cada 15 minutos para acumular datos del hogar
//     private func startDataCollection() {
//         dataCollectionTimer = Timer.scheduledTimer(withTimeInterval: 900.0, repeats: true) { [weak self] _ in
//             self?.collectTrainingDataPoint()
//         }
//         collectTrainingDataPoint()
//     }
//
//     private func collectTrainingDataPoint() {
//         let calendar = Calendar.current
//         let now = Date()
//         let hour = Double(calendar.component(.hour, from: now))
//         let dayOfWeek = Double(calendar.component(.weekday, from: now))
//         let consumption = totalConsumption
//         let presenceAtHome = isAtHome ? 1.0 : 0.0
//
//         // En producción usar WeatherKit:
//         // let temperature = await fetchCurrentTemperature()
//         let temperature = 25.0
//
//         // Calcular label con heurística multi-factor:
//         // Apagar recomendado si: es tarde de noche + consumo alto + nadie en casa
//         let isLateNight = hour >= 23 || hour < 6
//         let isHighConsumption = consumption > 0.5
//         let isUnoccupied = presenceAtHome == 0.0
//         let label: Double = (isLateNight && isHighConsumption && isUnoccupied) ? 1.0 : 0.0
//
//         let point = TrainingPoint(
//             hour: hour,
//             dayOfWeek: dayOfWeek,
//             consumption: consumption,
//             presenceAtHome: presenceAtHome,
//             temperature: temperature,
//             label: label
//         )
//
//         trainingHistory.append(point)
//         if trainingHistory.count > 500 { trainingHistory.removeFirst() }
//
//         // Guardar punto en CoreData para persistencia entre sesiones
//         recordEnergyReading(device: devices.first ?? HomeDevice(
//             id: UUID(), name: "General", icon: "bolt", room: "Casa",
//             isOn: true, consumption: consumption,
//             isCharging: false, chargeLevel: 100, hmIdentifier: ""
//         ))
//
//         checkForPatternChange()
//     }
//
//     // MARK: - Entrenamiento real de la red neuronal
//     // Se ejecuta en background para no bloquear la UI
//     // Usa mini-batch de 32 puntos para eficiencia
//     func trainNeuralNetwork() {
//         guard trainingHistory.count >= 10 else { return }
//         isTraining = true
//
//         DispatchQueue.global(qos: .background).async { [weak self] in
//             guard let self = self else { return }
//
//             let batchSize = min(32, self.trainingHistory.count)
//             let batch = Array(self.trainingHistory.shuffled().prefix(batchSize))
//
//             // Backpropagation real con los datos del hogar
//             self.neuralNet.train(batch: batch, learningRate: 0.001)
//
//             // Persistir pesos en UserDefaults para la próxima sesión
//             self.saveWeights()
//
//             DispatchQueue.main.async { self.isTraining = false }
//         }
//     }
//
//     // MARK: - Persistencia de pesos de la red neuronal
//     // Se guardan en UserDefaults como array de Double
//     // En producción se podría usar Keychain para mayor seguridad
//     private func saveWeights() {
//         let weights = neuralNet.toWeightsArray()
//         UserDefaults.standard.set(weights, forKey: "tonalli_nn_weights_v1")
//     }
//
//     private func loadSavedWeights() {
//         guard let weights = UserDefaults.standard.array(
//             forKey: "tonalli_nn_weights_v1"
//         ) as? [Double], weights.count == 113
//         else { return }
//         neuralNet.fromWeightsArray(weights)
//     }
//
//     // MARK: - Inferencia real con la red neuronal entrenada
//     // Analiza TODOS los dispositivos activos y calcula
//     // la probabilidad de que convenga apagarlos ahora
//     func smartRecommendation() -> String {
//         let calendar = Calendar.current
//         let now = Date()
//         let hour = Double(calendar.component(.hour, from: now))
//         let dayOfWeek = Double(calendar.component(.weekday, from: now))
//         let presenceAtHome = isAtHome ? 1.0 : 0.0
//         let temperature = 25.0 // En prod: WeatherKit
//
//         var recs: [String] = []
//
//         for device in devices where device.isOn {
//             let input = [
//                 hour / 23.0,
//                 (dayOfWeek - 1) / 6.0,
//                 min(device.consumption / 3.0, 1.0),
//                 presenceAtHome,
//                 min(max(temperature - 5.0, 0) / 45.0, 1.0)
//             ]
//             let (probability, _) = neuralNet.predict(input: input)
//
//             // Umbral 0.65: balance entre precisión y recall
//             // Más alto = menos recomendaciones pero más precisas
//             if probability > 0.65 {
//                 recs.append("\(device.name) (\(String(format: "%.0f%%", probability * 100)))")
//             }
//         }
//
//         if recs.isEmpty {
//             return "Todo está optimizado para este horario."
//         }
//         let saving = String(format: "%.0f", max(0, totalConsumption * 0.5 * 2.80))
//         return "Conviene apagar: \(recs.joined(separator: ", ")). Ahorro ~$\(saving) pesos."
//     }
//
//     // MARK: - Recomendar solo perfil más eficiente que el actual
//     // La IA nunca recomienda consumir más — solo ahorrar
//     func computeDowngradeProfile() -> UserProfile? {
//         let calendar = Calendar.current
//         let now = Date()
//         let hour = Double(calendar.component(.hour, from: now))
//         let dayOfWeek = Double(calendar.component(.weekday, from: now))
//
//         let input = [
//             hour / 23.0,
//             (dayOfWeek - 1) / 6.0,
//             min(totalConsumption / 3.0, 1.0),
//             isAtHome ? 1.0 : 0.0,
//             0.5 // Temperatura normalizada promedio
//         ]
//
//         let (probability, _) = neuralNet.predict(input: input)
//
//         // Alta probabilidad → recomendar perfil más agresivo de ahorro
//         // Solo si el perfil recomendado es más eficiente que el actual
//         switch selectedUserProfile {
//         case .confort:
//             if probability > 0.7 { return .ahorro }
//             if probability > 0.45 { return .balanceado }
//             return nil
//         case .balanceado:
//             if probability > 0.7 { return .ahorro }
//             return nil
//         case .ahorro:
//             return nil // Ya en el perfil más eficiente
//         }
//     }
//
//     // MARK: - Sensor de batería real
//     @objc private func batteryLevelChanged() {
//         let level = UIDevice.current.batteryLevel
//         let state = UIDevice.current.batteryState
//
//         // Notificar al usuario cuando la carga completa
//         // para que pueda desconectar y proteger la batería
//         if level >= 0.99 && (state == .full || state == .charging) {
//             sendNotification(
//                 notifID: "battery_full",
//                 title: "iPhone completamente cargado",
//                 body: "Puedes desconectarlo para proteger la batería."
//             )
//         }
//
//         // Pausar EcoLearn si baja de 20% para no afectar al usuario
//         if level < 0.20 && ecoMode {
//             sendNotification(
//                 notifID: "battery_low_eco",
//                 title: "EcoLearn en pausa",
//                 body: "La batería está al 20%. EcoLearn se reactivará cuando cargues."
//             )
//         }
//     }
//
//     @objc private func batteryStateChanged() {
//         let state = UIDevice.current.batteryState
//         let level = UIDevice.current.batteryLevel
//
//         // Reanudar EcoLearn cuando el usuario conecta el cargador
//         // con suficiente batería para no afectar su experiencia
//         if (state == .charging || state == .full) && level > 0.20 && ecoMode {
//             scheduleBackgroundTraining()
//         }
//     }
//
//     // MARK: - BGProcessingTask para entrenamiento real en background
//     // iOS ejecuta esta tarea cuando el iPhone está:
//     // - Conectado al cargador
//     // - En reposo (pantalla apagada)
//     // - En una red WiFi conocida
//     // iOS decide cuándo ejecutar basado en patrones de uso del usuario
//     func scheduleBackgroundTraining() {
//         let request = BGProcessingTaskRequest(identifier: "com.tonalli.training")
//         request.requiresNetworkConnectivity = true  // Para enviar pesos al servidor
//         request.requiresExternalPower = true         // Solo al cargar
//
//         do {
//             try BGTaskScheduler.shared.submit(request)
//         } catch {
//             print("BGTask error: \(error)")
//         }
//     }
//
//     // Se registra en TonalliApp.init() y se llama por iOS en background
//     static func handleBackgroundTask(_ task: BGProcessingTask) {
//         // Cancelar limpiamente si iOS necesita los recursos
//         task.expirationHandler = {
//             task.setTaskCompleted(success: false)
//         }
//
//         // Verificar condiciones de batería antes de entrenar
//         UIDevice.current.isBatteryMonitoringEnabled = true
//         let level = UIDevice.current.batteryLevel
//         let state = UIDevice.current.batteryState
//         let isCharging = state == .charging || state == .full
//
//         guard isCharging && (level > 0.20 || level == -1) else {
//             task.setTaskCompleted(success: false)
//             return
//         }
//
//         DispatchQueue.global(qos: .background).async {
//             // Cargar datos de CoreData, entrenar y enviar pesos
//             // En producción aquí va toda la lógica de federated learning
//             task.setTaskCompleted(success: true)
//
//             // Programar la próxima ejecución automáticamente
//             let nextRequest = BGProcessingTaskRequest(identifier: "com.tonalli.training")
//             nextRequest.requiresNetworkConnectivity = true
//             nextRequest.requiresExternalPower = true
//             try? BGTaskScheduler.shared.submit(nextRequest)
//         }
//     }
//
//     // MARK: - Federated Learning real
//     // Solo se ejecuta cuando el iPhone está cargando y con >20% batería
//     // Los pesos reales de la red neuronal (113 valores) se envían al servidor
//     func runFederatedRound() {
//         guard ecoMode else { return }
//
//         // Verificar condiciones de hardware
//         let level = UIDevice.current.batteryLevel
//         let state = UIDevice.current.batteryState
//         let isCharging = state == .charging || state == .full
//         guard isCharging && (level > 0.20 || level == -1) else { return }
//
//         isTraining = true
//
//         DispatchQueue.global(qos: .background).async { [weak self] in
//             guard let self = self else { return }
//
//             // Paso 1: Entrenar con datos locales reales
//             if self.trainingHistory.count >= 10 {
//                 let batch = Array(self.trainingHistory.shuffled().prefix(32))
//                 self.neuralNet.train(batch: batch, learningRate: 0.001)
//                 self.saveWeights()
//             }
//
//             // Paso 2: Serializar pesos reales (113 valores)
//             let weights = self.neuralNet.toWeightsArray()
//
//             // Paso 3: Enviar al servidor con metadatos del entrenamiento
//             self.submitFederatedUpdate(weights: weights, numSamples: self.trainingHistory.count)
//         }
//     }
//
//     // Enviar actualización al servidor de Federated Learning
//     // El servidor aplica Federated Averaging ponderado por numSamples
//     // Más muestras = más peso en el promedio global
//     private func submitFederatedUpdate(weights: [Double], numSamples: Int) {
//         guard let url = URL(string: "\(serverURL)/submit_update") else { return }
//
//         var request = URLRequest(url: url)
//         request.httpMethod = "POST"
//         request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//         // En producción agregar autenticación JWT:
//         // request.setValue("Bearer \(jwtToken)", forHTTPHeaderField: "Authorization")
//
//         let body: [String: Any] = [
//             "user_id": userID,           // Anónimo — no es PII
//             "name": userName,            // Nombre del dispositivo (opcional)
//             "weights": weights,          // 113 valores de la red neuronal real
//             "num_samples": numSamples,   // Para FedAvg ponderado en el servidor
//             "model_version": "nn_5_16_1" // Control de versión de arquitectura
//         ]
//         request.httpBody = try? JSONSerialization.data(withJSONObject: body)
//
//         URLSession.shared.dataTask(with: request) { [weak self] data, _, _ in
//             guard let self = self,
//                   let data = data,
//                   let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
//             else { return }
//
//             DispatchQueue.main.async {
//                 self.isTraining = false
//                 self.myContributions += 1
//
//                 // CO₂ real: kWh_ahorrados × factor_México (0.450 kg CO₂/kWh)
//                 // Ahorro estimado por ronda: 0.007 kWh
//                 self.myCO2Saved += 0.007 * 0.450
//
//                 // Si el servidor devuelve pesos globales mejorados,
//                 // actualizar el modelo local con el conocimiento colectivo
//                 if let globalWeights = json["global_weights"] as? [Double],
//                    globalWeights.count == 113 {
//                     self.neuralNet.fromWeightsArray(globalWeights)
//                     self.saveWeights()
//                     print("Modelo actualizado con pesos globales — ronda \(self.globalRound)")
//                 }
//
//                 self.fetchStatus()
//                 self.fetchLeaderboard()
//             }
//         }.resume()
//     }
//
//     // MARK: - Detección de cambios de patrón
//     func checkForPatternChange() {
//         guard !showEcoPopup else { return }
//         let current = totalConsumption
//         let delta = abs(current - previousAvgConsumption)
//         roundsSinceLastCheck += 1
//
//         if delta > 0.3 && roundsSinceLastCheck > 15 {
//             let direction = current > previousAvgConsumption ? "aumentó" : "disminuyó"
//             let msg = "El consumo \(direction) \(String(format: "%.1f", delta * 100))%. La IA está actualizando tu perfil."
//             DispatchQueue.main.async {
//                 self.ecoPopupMessage = msg
//                 self.showEcoPopup = true
//             }
//             roundsSinceLastCheck = 0
//             previousAvgConsumption = current
//         }
//     }
//
//     // MARK: - Actualizar ahorro diario real
//     private func updateDailySavings() {
//         let maxPossible = devices.reduce(0) { $0 + $1.consumption }
//         let current = totalConsumption
//         let savedKW = maxPossible - current
//         // Proyección a 12 horas activas del día
//         dailySavingsKWh = max(0, savedKW * 12.0)
//     }
//
//     // MARK: - Aplicar perfil real via HomeKit
//     func applyProfile(_ profile: UserProfile) {
//         selectedUserProfile = profile
//         recommendedProfile = nil
//         currentProfile = profile.rawValue
//         showProfileSheet = false
//
//         // Determinar qué dispositivos deben encenderse/apagarse
//         for device in devices {
//             if device.name == "Refrigerador" { continue }
//             let shouldBeOn: Bool
//             switch profile {
//             case .ahorro:     shouldBeOn = device.consumption <= 0.1
//             case .balanceado: shouldBeOn = device.consumption <= 0.5
//             case .confort:    shouldBeOn = true
//             }
//             // Enviar comando real a HomeKit si el estado cambia
//             if shouldBeOn != device.isOn { toggleDevice(device: device) }
//         }
//         updateDailySavings()
//     }
//
//     // MARK: - Modo Vacaciones real via HomeKit
//     func toggleVacationMode() {
//         vacationMode.toggle()
//         if vacationMode {
//             // Guardar estado actual de cada dispositivo
//             for device in devices { preVacationState[device.name] = device.isOn }
//             // Apagar todo via HomeKit excepto Refrigerador
//             for device in devices where device.name != "Refrigerador" && device.isOn {
//                 toggleDevice(device: device)
//             }
//             currentProfile = "Vacaciones"
//         } else {
//             // Restaurar estado previo via HomeKit
//             for device in devices {
//                 let wasOn = preVacationState[device.name] ?? false
//                 if wasOn != device.isOn { toggleDevice(device: device) }
//             }
//             preVacationState = [:]
//             currentProfile = selectedUserProfile.rawValue
//         }
//     }
//
//     // MARK: - EcoLearn real
//     func requestEcoMode() { showEcoOnboarding = true }
//
//     func acceptEcoMode() {
//         showEcoOnboarding = false
//         ecoMode = true
//         currentProfile = "EcoLearn activo"
//         // Notificación de bienvenida — solo una vez por instalación
//         sendNotification(
//             notifID: "ecolearn_welcome",
//             title: "Bienvenido a EcoLearn",
//             body: "Solo actuaremos mientras tu teléfono esté cargando con más del 20% de batería."
//         )
//         startDataCollection()     // Empezar a recolectar datos reales
//         scheduleBackgroundTraining() // Programar BGProcessingTask
//         startFederatedTimer()     // Enviar pesos periódicamente
//     }
//
//     func declineEcoMode() { showEcoOnboarding = false; ecoMode = false }
//
//     func disableEcoMode() {
//         ecoMode = false
//         federatedTimer?.invalidate(); federatedTimer = nil
//         isTraining = false
//         currentProfile = selectedUserProfile.rawValue
//         resetNotification(notifID: "ecolearn_welcome")
//     }
//
//     private func startFederatedTimer() {
//         // En producción este timer solo dispara si hay batería y carga
//         // El trabajo pesado lo hace BGProcessingTask en background
//         federatedTimer = Timer.scheduledTimer(withTimeInterval: 8.0, repeats: true) { [weak self] _ in
//             self?.runFederatedRound()
//         }
//         runFederatedRound()
//     }
//
//     // MARK: - Notificaciones con deduplicación estricta
//     func requestNotificationPermission() {
//         UNUserNotificationCenter.current().requestAuthorization(
//             options: [.alert, .sound, .badge]
//         ) { granted, _ in print("Notificaciones: \(granted)") }
//     }
//
//     func sendNotification(notifID: String, title: String, body: String) {
//         guard !sentNotifications.contains(notifID) else { return }
//         sentNotifications.insert(notifID)
//         let content = UNMutableNotificationContent()
//         content.title = title; content.body = body; content.sound = .default
//         let request = UNNotificationRequest(
//             identifier: notifID,
//             content: content,
//             trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
//         )
//         UNUserNotificationCenter.current().add(request)
//     }
//
//     func resetNotification(notifID: String) { sentNotifications.remove(notifID) }
//
//     // MARK: - API del servidor
//     func fetchStatus() {
//         guard let url = URL(string: "\(serverURL)/status") else { return }
//         URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
//             guard let data = data,
//                   let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
//             else { return }
//             DispatchQueue.main.async {
//                 self?.globalRound = json["round"] as? Int ?? self?.globalRound ?? 0
//                 self?.activeUsers = json["active_users"] as? Int ?? self?.activeUsers ?? 0
//             }
//         }.resume()
//     }
//
//     func fetchLeaderboard() {
//         guard let url = URL(string: "\(serverURL)/leaderboard") else { return }
//         URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
//             guard let data = data,
//                   let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
//                   let board = json["leaderboard"] as? [[String: Any]]
//             else { return }
//             DispatchQueue.main.async {
//                 self?.leaderboard = board.prefix(5).map {
//                     LeaderEntry(
//                         name: $0["name"] as? String ?? "Usuario",
//                         co2: $0["co2_saved_kg"] as? Double ?? 0,
//                         contributions: $0["contributions"] as? Int ?? 0
//                     )
//                 }
//             }
//         }.resume()
//     }
//
//     // MARK: - AI Learning flow real
//     func toggleAILearning() {
//         aiLearningEnabled.toggle()
//         if aiLearningEnabled {
//             aiSheetPendingDismiss = false
//             resetNotification(notifID: "ai_suggestion")
//             resetNotification(notifID: "ai_devices")
//             if dataCollectionTimer == nil { startDataCollection() }
//             learningTimer = Timer.scheduledTimer(withTimeInterval: 60.0, repeats: true) { [weak self] _ in
//                 guard !(self?.aiSheetPendingDismiss ?? true) else { return }
//                 self?.runAIAnalysis()
//             }
//             DispatchQueue.main.asyncAfter(deadline: .now() + 2) { self.runAIAnalysis() }
//         } else {
//             learningTimer?.invalidate(); learningTimer = nil
//             aiSheetPendingDismiss = false; showAIResultSheet = false
//             resetNotification(notifID: "ai_suggestion")
//             resetNotification(notifID: "ai_devices")
//         }
//     }
//
//     func runAIAnalysis() {
//         guard aiLearningEnabled && !aiSheetPendingDismiss && !showAIResultSheet else { return }
//         DispatchQueue.global(qos: .background).asyncAfter(deadline: .now() + 1.5) { [weak self] in
//             guard let self = self else { return }
//             self.trainNeuralNetwork()  // Entrenar antes de analizar
//             let result = self.smartRecommendation()
//             let rec = self.computeDowngradeProfile()
//             DispatchQueue.main.async {
//                 guard !self.showAIResultSheet && !self.aiSheetPendingDismiss else { return }
//                 self.aiResultMessage = result
//                 self.recommendedProfile = rec
//                 self.aiSheetPendingDismiss = true
//                 self.showAIResultSheet = true
//                 if !result.contains("optimizado") {
//                     self.sendNotification(notifID: "ai_suggestion", title: "Sugerencia de IA", body: result)
//                 }
//             }
//         }
//     }
//
//     func dismissAISheet() {
//         showAIResultSheet = false; aiSheetPendingDismiss = false
//         let msg = smartRecommendation()
//         if !msg.contains("optimizado") {
//             sendNotification(notifID: "ai_devices", title: "Sugerencia de ahorro", body: msg)
//         }
//         resetNotification(notifID: "ai_suggestion")
//     }
//
//     func applyFromSheet(_ profile: UserProfile) {
//         applyProfile(profile)
//         showAIResultSheet = false; aiSheetPendingDismiss = false
//         resetNotification(notifID: "ai_suggestion")
//         resetNotification(notifID: "ai_devices")
//     }
//
//     func dismissEcoPopup() { showEcoPopup = false }
// }

// MARK: - Servidor Python real de Federated Learning
// El servidor de producción implementa:
//
// 1. Federated Averaging ponderado por número de muestras:
//    global_w = Σ(n_i / N_total * w_i)
//    Clientes con más datos tienen más influencia en el modelo global
//
// 2. Differential Privacy para mayor privacidad matemática:
//    a) Gradient clipping: limitar ||g|| ≤ C (C=1.0 típico)
//    b) Gaussian noise: agregar N(0, σ²C²I) a los gradientes agregados
//    c) Parámetro epsilon controla el trade-off privacidad/utilidad
//
// 3. Autenticación JWT para cada cliente:
//    POST /auth/token → {access_token, expires_in}
//    Todas las rutas protegidas con Bearer token
//
// 4. Base de datos PostgreSQL con tablas:
//    - users(id, device_name, contributions, co2_saved, joined_at)
//    - rounds(id, round_number, global_weights_json, timestamp)
//    - updates(id, user_id, round_id, num_samples, created_at)
//
// 5. Deploy con Docker en Railway o AWS ECS:
//    FROM python:3.11-slim
//    COPY requirements.txt .
//    RUN pip install -r requirements.txt
//    EXPOSE 8000
//    CMD ["uvicorn", "server:app", "--host", "0.0.0.0"]
//
// 6. HTTPS con certificado SSL de Let's Encrypt
//    URL producción: https://api.tonalli.mx
//
// Código Python del servidor de producción:
//
// from fastapi import FastAPI, Depends, HTTPException
// from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
// import numpy as np
// import asyncpg
// import jwt
//
// app = FastAPI()
// security = HTTPBearer()
//
// # Federated Averaging ponderado real
// def federated_average_weighted(updates: list[dict]) -> list[float]:
//     total_samples = sum(u["num_samples"] for u in updates)
//     n_weights = len(updates[0]["weights"])
//     result = [0.0] * n_weights
//     for update in updates:
//         weight_factor = update["num_samples"] / total_samples
//         for i in range(n_weights):
//             result[i] += weight_factor * update["weights"][i]
//     return result
//
// # Differential Privacy: clip + noise
// def apply_differential_privacy(weights: list[float], clip_norm: float = 1.0, noise_sigma: float = 0.01) -> list[float]:
//     w = np.array(weights)
//     norm = np.linalg.norm(w)
//     if norm > clip_norm:
//         w = w * (clip_norm / norm)  # Gradient clipping
//     w += np.random.normal(0, noise_sigma * clip_norm, w.shape)  # Gaussian noise
//     return w.tolist()
//
// @app.post("/submit_update")
// async def submit_update(data: dict, credentials: HTTPAuthorizationCredentials = Depends(security)):
//     # Verificar JWT del cliente
//     try:
//         payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=["HS256"])
//     except jwt.InvalidTokenError:
//         raise HTTPException(status_code=401, detail="Token inválido")
//
//     user_id = data["user_id"]
//     weights = data["weights"]
//     num_samples = data["num_samples"]
//
//     # Guardar actualización en PostgreSQL
//     await db.execute(
//         "INSERT INTO updates(user_id, weights_json, num_samples) VALUES($1, $2, $3)",
//         user_id, json.dumps(weights), num_samples
//     )
//
//     # Agregar a la ronda actual
//     pending_updates.append({"weights": weights, "num_samples": num_samples})
//
//     # Cada 10 actualizaciones, calcular nuevo modelo global
//     if len(pending_updates) >= 10:
//         global_weights = federated_average_weighted(pending_updates)
//         global_weights = apply_differential_privacy(global_weights)
//         pending_updates.clear()
//         current_round += 1
//         await save_round_to_db(global_weights, current_round)
//
//     return {"status": "ok", "round": current_round, "global_weights": global_weights}

*/
