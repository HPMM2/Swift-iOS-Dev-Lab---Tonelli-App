//
//  TonalliApp.swift
//  Tonalli
//
//  Created by Manuel Flores Mata on 04/05/26.
//

import SwiftUI

@main
struct TonalliApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
