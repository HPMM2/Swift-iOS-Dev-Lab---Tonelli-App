import Foundation

struct HomeDevice: Identifiable {
    let id = UUID()
    var name: String
    let icon: String
    let room: String
    var isOn: Bool
    var consumption: Double
    var isCharging: Bool = false
    var chargeLevel: Int = 100
}

struct TrainingPoint {
    let hour: Double
    let consumption: Double
    let label: Double
}

struct LeaderEntry: Identifiable {
    let id = UUID()
    let name: String
    let co2: Double
    let contributions: Int
}

struct EnergyDataPoint: Identifiable {
    let id = UUID()
    let label: String
    let value: Double
}

enum UserProfile: String, CaseIterable, Identifiable {
    case ahorro = "Ahorro maximo"
    case balanceado = "Balanceado"
    case confort = "Confort"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .ahorro: return "leaf.circle.fill"
        case .balanceado: return "slider.horizontal.3"
        case .confort: return "star.circle.fill"
        }
    }

    var description: String {
        switch self {
        case .ahorro: return "Apaga dispositivos no esenciales. Maximiza ahorro en CFE."
        case .balanceado: return "Equilibrio entre confort y eficiencia. Solo dispositivos moderados activos."
        case .confort: return "Todos los dispositivos activos segun tu rutina normal."
        }
    }

    var consumptionThreshold: Double {
        switch self {
        case .ahorro: return 0.1
        case .balanceado: return 0.5
        case .confort: return 99.0
        }
    }

    var devicesOn: [String] {
        switch self {
        case .ahorro: return ["Refrigerador"]
        case .balanceado: return ["Refrigerador", "Sala", "iPhone"]
        case .confort: return ["Refrigerador", "Sala", "iPhone", "TV", "Aire acondicionado", "Lavadora"]
        }
    }
}


import Foundation

// ============================================================
// MARK: - TONALLI — LÓGICA REAL (COMENTADA PARA REFERENCIA)
// ============================================================
// Este archivo muestra la implementación real de producción.
// Todo el código está comentado intencionalmente.
// La versión de presentación usa datos simulados para
// demostrar el flujo sin requerir hardware real ni
// entitlements de Apple Developer ($99/año).
//
// Para llevar a producción se necesita:
// 1. Apple Developer Program activo
// 2. Dispositivos HomeKit físicos (Eve Energy, Kasa EP25, etc.)
// 3. Servidor en la nube con HTTPS (Railway, AWS, GCP)
// 4. Activar los entitlements en Xcode:
//    - HomeKit
//    - Background Modes (fetch + processing)
//    - iCloud (opcional para sincronización)
// ============================================================

/*

import HomeKit
import CoreData
import CoreMotion
import BackgroundTasks

// MARK: - HomeDevice real construido desde HMAccessory
// En producción no se define manualmente — viene de HomeKit.
// Cada accesorio físico en el hogar del usuario genera
// automáticamente un HomeDevice al cargar la app.
//
// struct HomeDevice: Identifiable {
//     let id: UUID          // HMAccessory.uniqueIdentifier
//     var name: String      // HMAccessory.name (editable por usuario)
//     let icon: String      // Inferido de HMAccessoryCategoryType
//     let room: String      // HMRoom.name del accesorio
//     var isOn: Bool        // Valor real de HMCharacteristicTypePowerState
//     var consumption: Double // kW medido por sensor real (Eve Energy / Kasa EP25)
//     var isCharging: Bool  // UIDevice.current.batteryState == .charging
//     var chargeLevel: Int  // Int(UIDevice.current.batteryLevel * 100)
//     var hmIdentifier: String // Para buscar el accesorio en HomeKit y mandar comandos
// }

// MARK: - TrainingPoint con datos reales del sistema
// Cada punto se genera con datos medidos en tiempo real:
// - Hora exacta del sistema operativo
// - Día de la semana para detectar patrones semanales
// - Consumo en kW medido por enchufes inteligentes
// - Presencia detectada por CoreMotion (acelerómetro)
// - Temperatura exterior de WeatherKit (iOS 16+)
// - Label calculado con heurística: hora nocturna + consumo alto + nadie en casa
//
// struct TrainingPoint {
//     let hour: Double           // Calendar.current.component(.hour, from: Date())
//     let dayOfWeek: Double      // Calendar.current.component(.weekday, from: Date())
//     let consumption: Double    // kW real medido por HMCharacteristic de potencia
//     let presenceAtHome: Double // CMMotionActivity: 0.0 = fuera, 1.0 = en casa
//     let temperature: Double    // Celsius de WeatherService.shared.weather(for: location)
//     let label: Double          // 1.0 = apagar recomendado, 0.0 = dejar encendido
// }

// MARK: - LeaderEntry desde el servidor real
// En producción viene del endpoint GET /leaderboard del servidor.
// Los valores de CO₂ se calculan con el factor de emisión real
// de la red eléctrica mexicana: 0.450 kg CO₂ por kWh
// (Fuente: SENER — Secretaría de Energía, 2024)
//
// struct LeaderEntry: Identifiable {
//     let id = UUID()
//     let name: String       // Nombre del dispositivo del usuario (anónimo)
//     let co2: Double        // kg CO₂ ahorrado = kWh_ahorrados * 0.450
//     let contributions: Int // Número de rondas de entrenamiento completadas
// }

// MARK: - EnergyDataPoint desde CoreData
// En producción los datos de las gráficas vienen de lecturas
// reales guardadas en CoreData cada 15 minutos.
// Schema CoreData: timestamp(Date), consumption(Double),
// deviceName(String), isOn(Bool), room(String)
//
// struct EnergyDataPoint: Identifiable {
//     let id = UUID()
//     let label: String  // Etiqueta del eje X (hora, día, semana)
//     let value: Double  // kWh real medido y guardado en CoreData
// }

// MARK: - UserProfile con umbrales calibrados automáticamente
// En producción los umbrales de consumo se calibran
// dinámicamente con los datos reales del hogar de cada usuario.
// El modelo aprende que para ESTE hogar específico,
// un dispositivo eficiente consume menos de X kW.
//
// enum UserProfile: String, CaseIterable, Identifiable {
//     case ahorro = "Ahorro máximo"
//     case balanceado = "Balanceado"
//     case confort = "Confort"
//
//     // consumptionThreshold se calibra automáticamente
//     // analizando el historial de consumo del hogar:
//     // ahorro    = percentil 25 del consumo histórico
//     // balanceado = percentil 50 (mediana)
//     // confort   = sin restricción
//     var consumptionThreshold: Double {
//         switch self {
//         case .ahorro:     return calculatedP25  // Dinámico por hogar
//         case .balanceado: return calculatedP50  // Dinámico por hogar
//         case .confort:    return 99.0
//         }
//     }
// }

// MARK: - Red neuronal real: arquitectura 5 → 16 → 1
// Reemplaza la regresión logística simple de la demo.
// Tiene mayor capacidad para capturar patrones no lineales:
// ej. "apagar el clima solo cuando es tarde Y hace calor Y nadie está"
//
// Arquitectura:
// - Input: 5 features normalizadas al rango [0, 1]
// - Capa oculta: 16 neuronas con activación ReLU
// - Capa de salida: 1 neurona con activación Sigmoid
// - Output: probabilidad 0.0-1.0 de que convenga apagar
//
// struct NeuralNetwork {
//
//     // Pesos capa 1: 5 entradas × 16 neuronas = 80 valores
//     // Inicialización Xavier: escala = sqrt(2/5) para ReLU
//     var W1: [[Double]]  // 5 × 16
//     var b1: [Double]    // 16 bias de capa oculta
//
//     // Pesos capa 2: 16 neuronas × 1 salida = 16 valores
//     // Inicialización Xavier: escala = sqrt(2/16)
//     var W2: [Double]    // 16
//     var b2: Double      // 1 bias de capa de salida
//
//     // Total de parámetros: 80 + 16 + 16 + 1 = 113
//     // Este número exacto se serializa para Federated Learning
//
//     init() {
//         let scale1 = sqrt(2.0 / 5.0)   // Xavier para ReLU, 5 entradas
//         let scale2 = sqrt(2.0 / 16.0)  // Xavier para ReLU, 16 entradas
//         W1 = (0..<5).map { _ in (0..<16).map { _ in Double.random(in: -scale1...scale1) } }
//         b1 = [Double](repeating: 0.0, count: 16)
//         W2 = (0..<16).map { _ in Double.random(in: -scale2...scale2) }
//         b2 = 0.0
//     }
//
//     // Activación ReLU: max(0, x)
//     // Introduce no-linealidad sin el problema de vanishing gradient
//     private func relu(_ x: Double) -> Double { max(0.0, x) }
//
//     // Derivada de ReLU para backpropagation
//     // 1 si x > 0, 0 si x <= 0
//     private func reluDerivative(_ x: Double) -> Double { x > 0 ? 1.0 : 0.0 }
//
//     // Activación Sigmoid: 1/(1+e^-x)
//     // Convierte la salida a probabilidad [0, 1]
//     private func sigmoid(_ x: Double) -> Double { 1.0 / (1.0 + exp(-x)) }
//
//     // Forward pass: calcular predicción dado un input
//     // Retorna también las activaciones ocultas para backprop
//     func predict(input: [Double]) -> (output: Double, hidden: [Double]) {
//         // Paso 1: multiplicar input por pesos de capa oculta
//         // h_j = ReLU(Σ W1[i][j] * x[i] + b1[j])
//         var hidden = [Double](repeating: 0.0, count: 16)
//         for j in 0..<16 {
//             var sum = b1[j]
//             for i in 0..<5 {
//                 sum += W1[i][j] * input[i]
//             }
//             hidden[j] = relu(sum)
//         }
//
//         // Paso 2: multiplicar activaciones ocultas por pesos de salida
//         // y_hat = Sigmoid(Σ W2[j] * h[j] + b2)
//         var outputSum = b2
//         for j in 0..<16 {
//             outputSum += W2[j] * hidden[j]
//         }
//         return (sigmoid(outputSum), hidden)
//     }
//
//     // Backpropagation real con mini-batch gradient descent
//     // Actualiza todos los pesos W1, b1, W2, b2 en una sola pasada
//     // usando la regla de la cadena para propagar el error
//     mutating func train(batch: [TrainingPoint], learningRate: Double = 0.001) {
//
//         // Acumuladores de gradiente para el batch
//         var gradW1 = [[Double]](repeating: [Double](repeating: 0.0, count: 16), count: 5)
//         var gradb1 = [Double](repeating: 0.0, count: 16)
//         var gradW2 = [Double](repeating: 0.0, count: 16)
//         var gradb2 = 0.0
//
//         for point in batch {
//             // Normalizar features al rango [0, 1]
//             let input = normalizeFeatures(point)
//
//             // Forward pass
//             let (output, hidden) = predict(input: input)
//
//             // Error en salida: derivada de Binary Cross-Entropy
//             // dL/dy_hat = y_hat - y_true
//             let outputError = output - point.label
//
//             // Gradientes capa de salida
//             // dL/dW2[j] = outputError * hidden[j]
//             // dL/db2 = outputError
//             gradb2 += outputError
//             for j in 0..<16 {
//                 gradW2[j] += outputError * hidden[j]
//             }
//
//             // Backpropagation a capa oculta
//             // dL/dh[j] = outputError * W2[j] * relu'(h[j])
//             var hiddenError = [Double](repeating: 0.0, count: 16)
//             for j in 0..<16 {
//                 hiddenError[j] = outputError * W2[j] * reluDerivative(hidden[j])
//             }
//
//             // Gradientes capa oculta
//             // dL/dW1[i][j] = hiddenError[j] * input[i]
//             for i in 0..<5 {
//                 for j in 0..<16 {
//                     gradW1[i][j] += hiddenError[j] * input[i]
//                 }
//             }
//             for j in 0..<16 {
//                 gradb1[j] += hiddenError[j]
//             }
//         }
//
//         // Actualizar pesos con promedio del batch y learning rate
//         // w = w - lr * (1/N) * Σ gradientes
//         let n = Double(batch.count)
//         b2 -= learningRate * gradb2 / n
//         for j in 0..<16 {
//             W2[j] -= learningRate * gradW2[j] / n
//             b1[j] -= learningRate * gradb1[j] / n
//         }
//         for i in 0..<5 {
//             for j in 0..<16 {
//                 W1[i][j] -= learningRate * gradW1[i][j] / n
//             }
//         }
//     }
//
//     // Normalizar los 5 features al rango [0, 1]
//     // Necesario para que el gradiente descendente converja bien
//     private func normalizeFeatures(_ point: TrainingPoint) -> [Double] {
//         [
//             point.hour / 23.0,                        // Hora: 0-23 → 0-1
//             (point.dayOfWeek - 1.0) / 6.0,            // Día: 1-7 → 0-1
//             min(point.consumption / 3.0, 1.0),        // kW: clip a 3 kW máximo
//             point.presenceAtHome,                     // Ya está en 0-1
//             min(max(point.temperature - 5.0, 0.0) / 45.0, 1.0) // 5-50°C → 0-1
//         ]
//     }
//
//     // Serializar 113 pesos a array plano para Federated Learning
//     // El servidor recibe estos valores y calcula el promedio global
//     // Orden: W1 (80) + b1 (16) + W2 (16) + b2 (1) = 113 valores
//     func toWeightsArray() -> [Double] {
//         var weights: [Double] = []
//         for row in W1 { weights += row }  // 80 valores
//         weights += b1                      // 16 valores
//         weights += W2                      // 16 valores
//         weights.append(b2)                 // 1 valor
//         return weights                     // Total: 113
//     }
//
//     // Deserializar pesos globales del servidor
//     // Se llama después de cada ronda de Federated Averaging
//     // El modelo local mejora con el conocimiento colectivo
//     mutating func fromWeightsArray(_ weights: [Double]) {
//         guard weights.count == 113 else { return }
//         var idx = 0
//         for i in 0..<5 {
//             for j in 0..<16 {
//                 W1[i][j] = weights[idx]; idx += 1
//             }
//         }
//         for j in 0..<16 { b1[j] = weights[idx]; idx += 1 }
//         for j in 0..<16 { W2[j] = weights[idx]; idx += 1 }
//         b2 = weights[idx]
//     }
// }

// MARK: - Entidad CoreData para historial real de energía
// Se guarda una lectura cada 15 minutos de cada dispositivo.
// Permite análisis histórico real por hora, día, semana y mes.
// Los datos son privados — nunca salen del dispositivo.
//
// Para crear en Xcode:
// File → New → File → Data Model → Agregar entidad EnergyReading
//
// Atributos de EnergyReading:
// - timestamp:   Date    (cuándo se tomó la lectura)
// - consumption: Double  (kW medidos por HomeKit)
// - deviceName:  String  (nombre del accesorio)
// - isOn:        Bool    (estado en ese momento)
// - room:        String  (habitación del accesorio)
//
// @objc(EnergyReading)
// class EnergyReading: NSManagedObject {
//     @NSManaged var timestamp: Date
//     @NSManaged var consumption: Double
//     @NSManaged var deviceName: String
//     @NSManaged var isOn: Bool
//     @NSManaged var room: String
// }

// MARK: - Entidad CoreData para configuración persistente
// Guarda los ajustes del usuario entre sesiones
//
// Atributos de UserConfiguration:
// - profileRaw:        String  (rawValue del UserProfile seleccionado)
// - ecoModeEnabled:    Bool    (si EcoLearn está activo)
// - aiLearningEnabled: Bool    (si la IA está aprendiendo)
// - isDarkMode:        Bool    (preferencia de modo de color)
// - contributions:     Int32   (rondas de entrenamiento acumuladas)
// - co2Saved:          Double  (kg CO₂ ahorrados acumulados)
//
// @objc(UserConfiguration)
// class UserConfiguration: NSManagedObject {
//     @NSManaged var profileRaw: String
//     @NSManaged var ecoModeEnabled: Bool
//     @NSManaged var aiLearningEnabled: Bool
//     @NSManaged var isDarkMode: Bool
//     @NSManaged var contributions: Int32
//     @NSManaged var co2Saved: Double
// }

// MARK: - PersistenceController para CoreData
// Singleton que gestiona el stack de CoreData
// Soporta CloudKit para sincronización opcional entre dispositivos
//
// class PersistenceController {
//     static let shared = PersistenceController()
//
//     let container: NSPersistentCloudKitContainer
//
//     init() {
//         // NSPersistentCloudKitContainer sincroniza automáticamente
//         // con iCloud si el usuario tiene sesión iniciada
//         container = NSPersistentCloudKitContainer(name: "Tonalli")
//         container.loadPersistentStores { _, error in
//             if let error = error {
//                 fatalError("Error CoreData: \(error)")
//             }
//         }
//         container.viewContext.automaticallyMergesChangesFromParent = true
//     }
// }

// MARK: - Factor de emisión de CO₂ real para México
// La red eléctrica de México emite 450g de CO₂ por kWh
// según datos oficiales de SENER 2024.
// Este factor varía por región y hora del día.
// En producción se consultaría la API de CENACE
// (Centro Nacional de Control de Energía) para el factor
// en tiempo real según la hora y la zona del usuario.
//
// struct CO2Calculator {
//     // Factor promedio anual México 2024 (SENER)
//     static let mexicoGridFactor = 0.450 // kg CO₂ por kWh
//
//     // Calcular CO₂ ahorrado por reducir X kWh
//     static func co2Saved(kwhReduced: Double) -> Double {
//         return kwhReduced * mexicoGridFactor
//     }
//
//     // Calcular CO₂ equivalente en árboles plantados
//     // Un árbol absorbe ~21 kg CO₂ al año
//     static func treesEquivalent(kgCO2: Double) -> Double {
//         return kgCO2 / 21.0
//     }
//
//     // Calcular litros de agua equivalentes
//     // Generar 1 kWh en termoeléctricas requiere ~2.0 litros
//     static func waterSaved(kwhReduced: Double) -> Double {
//         return kwhReduced * 2.0
//     }
// }

*/
