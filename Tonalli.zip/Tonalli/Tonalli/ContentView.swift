import SwiftUI

struct ContentView: View {
    @StateObject var vm = TonalliViewModel()
    @State var selectedTab = 0

    var dark: Bool { vm.isDarkMode }

    var body: some View {
        ZStack {
            pageBackground(dark).ignoresSafeArea()
            VStack(spacing: 0) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 2) {
                        Image(dark ? "IconoOscuro" : "IconoClaro")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 52)
                            .cornerRadius(10)
                            .accessibilityHidden(true)
                        Text("Hogar inteligente · \(vm.currentProfile)")
                            .font(.system(size: 11))
                            .foregroundColor(secondaryText(dark))
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("Tonalli, Hogar inteligente. Perfil actual: \(vm.currentProfile)")
                    .accessibilityAddTraits(.isHeader)
                    
                    Spacer()
                    
                    Button {
                        withAnimation { vm.isDarkMode.toggle() }
                    } label: {
                        Image(systemName: dark ? "sun.max.fill" : "moon.fill")
                            .font(.system(size: 18))
                            .foregroundColor(dark ? .yellow : Color(red: 0.3, green: 0.3, blue: 0.6))
                            .padding(10)
                            .background(dark ? Color.yellow.opacity(0.15) : Color(red: 0.3, green: 0.3, blue: 0.6).opacity(0.1))
                            .cornerRadius(20)
                    }
                    .accessibilityLabel("Modo de apariencia")
                    .accessibilityValue(dark ? "Oscuro" : "Claro")
                    .accessibilityHint("Toca para cambiar el tema visual de la aplicación")
                    
                    if vm.ecoMode {
                        HStack(spacing: 6) {
                            Circle().fill(accentGreen).frame(width: 7, height: 7)
                                .scaleEffect(vm.isTraining ? 1.4 : 1.0)
                                .animation(.easeInOut(duration: 0.5).repeatForever(), value: vm.isTraining)
                            Text("Eco").font(.system(size: 12, weight: .semibold)).foregroundColor(accentGreen)
                        }
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(accentGreen.opacity(0.12))
                        .cornerRadius(20)
                        .accessibilityElement(children: .combine)
                        .accessibilityLabel(vm.isTraining ? "Modo Eco activo y contribuyendo" : "Modo Eco activo")
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 16)

                ScrollView(showsIndicators: false) {
                    if selectedTab == 0 {
                        HomeTab(vm: vm, dark: dark, selectedTab: $selectedTab)
                    } else if selectedTab == 1 {
                        EnergyTab(vm: vm, dark: dark)
                    } else {
                        EcoLearnTab(vm: vm, dark: dark)
                    }
                }

                HStack(spacing: 4) {
                    TabBtn(title: "Hogar", icon: "house.fill", selected: selectedTab == 0, dark: dark) { selectedTab = 0 }
                    TabBtn(title: "Energía", icon: "bolt.fill", selected: selectedTab == 1, dark: dark) { selectedTab = 1 }
                    TabBtn(title: "EcoLearn", icon: "leaf.fill", selected: selectedTab == 2, dark: dark) { selectedTab = 2 }
                }
                .padding(6)
                .background(cardBackground(dark))
                .cornerRadius(20)
                .shadow(color: .black.opacity(0.06), radius: 10, x: 0, y: -2)
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
                .padding(.top, 8)
            }
        }
        .sheet(isPresented: $vm.showAIResultSheet, onDismiss: { vm.dismissAISheet() }) {
            AIResultSheet(
                message: vm.aiResultMessage,
                recommendedProfile: vm.recommendedProfile,
                dark: dark,
                onApply: { profile in vm.applyFromSheet(profile) },
                onDismiss: { vm.dismissAISheet() }
            )
            .presentationDetents([.medium])
        }
        .sheet(isPresented: $vm.showProfileSheet) {
            ProfileSheet(
                selected: vm.selectedUserProfile,
                recommended: vm.recommendedProfile,
                dark: dark,
                onSelect: { vm.applyProfile($0) },
                onDismiss: { vm.showProfileSheet = false }
            )
            .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $vm.showEcoPopup, onDismiss: { vm.dismissEcoPopup() }) {
            EcoPopup(
                message: vm.ecoPopupMessage,
                dark: dark,
                onDismiss: { vm.dismissEcoPopup() }
            )
            .presentationDetents([.height(360)])
        }
        .sheet(isPresented: $vm.showEcoOnboarding) {
            EcoLearnOnboardingSheet(
                dark: dark,
                onAccept: { vm.acceptEcoMode() },
                onDecline: { vm.declineEcoMode() }
            )
            .presentationDetents([.large])
        }
    }
}

struct HomeTab: View {
    @ObservedObject var vm: TonalliViewModel
    let dark: Bool
    @Binding var selectedTab: Int
    @State var showAddDevice = false

    var activeCount: Int { vm.devices.filter { $0.isOn }.count }

    var body: some View {
        VStack(spacing: 20) {
            HStack(spacing: 12) {
                ModeCard(title: "Vacaciones", subtitle: "Apaga todo", icon: "airplane", color: accentBlue, isActive: vm.vacationMode, dark: dark) { vm.toggleVacationMode() }
                ModeCard(title: "Perfil", subtitle: vm.selectedUserProfile.rawValue, icon: vm.selectedUserProfile.icon, color: profileColor(vm.selectedUserProfile), isActive: false, dark: dark) { vm.showProfileSheet = true }
                ModeCard(title: "IA", subtitle: vm.aiLearningEnabled ? "Aprendiendo" : "Inactiva", icon: "brain", color: .purple, isActive: vm.aiLearningEnabled, dark: dark) { vm.toggleAILearning() }
            }
            .padding(.horizontal, 20)

            Button { selectedTab = 1 } label: {
                HStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Ahorro del Día")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(secondaryText(dark))
                        HStack(alignment: .firstTextBaseline, spacing: 4) {
                            Text(String(format: "%.2f kWh", vm.dailySavingsKWh))
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(accentGreen)
                            Text("ahorrados")
                                .font(.system(size: 12))
                                .foregroundColor(secondaryText(dark))
                        }
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        Text("Estimado")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(secondaryText(dark))
                        HStack(alignment: .firstTextBaseline, spacing: 4) {
                            Text(String(format: "$%.0f", vm.dailySavingsPesos))
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(accentBlue)
                            Text("menos")
                                .font(.system(size: 12))
                                .foregroundColor(secondaryText(dark))
                        }
                    }
                    Image(systemName: "chevron.right")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(secondaryText(dark))
                }
                .padding(16)
                .background(cardBackground(dark))
                .cornerRadius(20)
                .shadow(color: .black.opacity(dark ? 0.3 : 0.06), radius: 8, x: 0, y: 4)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(accentGreen.opacity(0.3), lineWidth: 1)
                )
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("Ahorro del Día: \(String(format: "%.2f", vm.dailySavingsKWh)) kilowatts hora ahorrados. Estimado de \(String(format: "%.0f", vm.dailySavingsPesos)) pesos menos.")
            .accessibilityHint("Toca para ir a la pestaña de energía")
            .padding(.horizontal, 20)

            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Dispositivos")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(secondaryText(dark))
                            .accessibilityAddTraits(.isHeader)
                        Text("\(activeCount) de \(vm.devices.count) activos")
                            .font(.system(size: 11))
                            .foregroundColor(secondaryText(dark).opacity(0.7))
                    }
                    .accessibilityElement(children: .combine)
                    
                    Spacer()
                    
                    Button { showAddDevice = true } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 26))
                            .foregroundColor(accentBlue)
                    }
                    .accessibilityLabel("Agregar dispositivo nuevo")
                }
                .padding(.horizontal, 20)

                LazyVGrid(
                    columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)],
                    spacing: 12
                ) {
                    ForEach($vm.devices) { $device in
                        DeviceCard(
                            device: $device,
                            dark: dark,
                            onDelete: {
                                vm.devices.removeAll { $0.id == device.id }
                            }
                        )
                        .frame(height: 140)
                    }
                }
                .padding(.horizontal, 20)
            }
        }
        .padding(.top, 8)
        .padding(.bottom, 32)
        .sheet(isPresented: $showAddDevice) {
            AddDeviceSheet(
                dark: dark,
                onAdd: { device in
                    vm.devices.append(device)
                    showAddDevice = false
                },
                onDismiss: { showAddDevice = false }
            )
            .presentationDetents([.large])
        }
    }
}

struct EnergyTab: View {
    @ObservedObject var vm: TonalliViewModel
    let dark: Bool
    @State var selectedRange = 0

    var currentData: [EnergyDataPoint] {
        switch selectedRange {
        case 0: return vm.energyDataDay
        case 1: return vm.energyDataWeek
        default: return vm.energyDataMonth
        }
    }

    var totalLabel: String {
        let total = currentData.reduce(0) { $0 + $1.value }
        switch selectedRange {
        case 0: return String(format: "%.1f kWh hoy", total * 0.5)
        case 1: return String(format: "%.1f kWh esta semana", total)
        default: return String(format: "%.0f kWh este mes", total)
        }
    }

    var costLabel: String {
        let total = currentData.reduce(0) { $0 + $1.value }
        let factor: Double = selectedRange == 0 ? 0.5 : 1.0
        return String(format: "~$%.0f pesos", total * factor * 1.5)
    }

    var body: some View {
        VStack(spacing: 20) {
            VStack(spacing: 6) {
                Text(String(format: "%.2f kW", vm.totalConsumption))
                    .font(.system(size: 52, weight: .bold))
                    .foregroundColor(primaryText(dark))
                Text("Consumo actual").font(.system(size: 13)).foregroundColor(secondaryText(dark))
                Text(String(format: "~$%.0f pesos / día", vm.estimatedDailyCost))
                    .font(.system(size: 13, weight: .medium)).foregroundColor(accentBlue)
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("Consumo actual: \(String(format: "%.2f", vm.totalConsumption)) kilowatts. Costo estimado: \(String(format: "%.0f", vm.estimatedDailyCost)) pesos por día.")
            .padding(.top, 20)

            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(totalLabel).font(.system(size: 15, weight: .bold)).foregroundColor(primaryText(dark))
                        Text(costLabel).font(.system(size: 12)).foregroundColor(secondaryText(dark))
                    }
                    .accessibilityElement(children: .combine)
                    
                    Spacer()
                    
                    Picker("", selection: $selectedRange) {
                        Text("Hoy").tag(0)
                        Text("Semana").tag(1)
                        Text("Mes").tag(2)
                    }
                    .pickerStyle(.segmented).frame(width: 160)
                    .accessibilityLabel("Rango de tiempo de energía")
                }

                let maxVal = currentData.map { $0.value }.max() ?? 1
                HStack(alignment: .bottom, spacing: 8) {
                    ForEach(currentData) { point in
                        EnergyBar(point: point, maxValue: maxVal, color: accentBlue, dark: dark)
                    }
                }
                .frame(height: 120)
            }
            .padding(16)
            .background(cardBackground(dark))
            .cornerRadius(20)
            .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
            .padding(.horizontal, 20)

            VStack(alignment: .leading, spacing: 14) {
                Text("Por dispositivo")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(secondaryText(dark))
                    .accessibilityAddTraits(.isHeader)

                ForEach(vm.devices.filter { $0.isOn }) { device in
                    HStack(spacing: 12) {
                        Image(systemName: device.icon).foregroundColor(accentBlue).frame(width: 18)
                            .accessibilityHidden(true)
                        Text(device.name).font(.system(size: 13)).foregroundColor(primaryText(dark)).frame(width: 80, alignment: .leading)
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 4).fill(accentBlue.opacity(0.08))
                                RoundedRectangle(cornerRadius: 4).fill(accentBlue)
                                    .frame(width: max(4, geo.size.width * (device.consumption / 1.5)))
                            }
                        }
                        .frame(height: 8)
                        Text(String(format: "%.2f", device.consumption))
                            .font(.system(size: 11)).foregroundColor(secondaryText(dark)).frame(width: 40, alignment: .trailing)
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("\(device.name), consumo: \(String(format: "%.2f", device.consumption)) kilowatts")
                }
            }
            .padding(16)
            .background(cardBackground(dark))
            .cornerRadius(20)
            .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
            .padding(.horizontal, 20)
            .padding(.bottom, 32)
        }
    }
}

struct EcoLearnTab: View {
    @ObservedObject var vm: TonalliViewModel
    let dark: Bool

    var body: some View {
        VStack(spacing: 20) {
            LinearGradient(
                colors: [accentGreen.opacity(0.85), accentBlue.opacity(0.7)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .frame(height: 180)
            .overlay(
                VStack(spacing: 10) {
                    Image(systemName: "globe.americas.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.white.opacity(0.9))
                        .accessibilityHidden(true)
                    Text("Juntos somos\nmás poderosos")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                }
                .accessibilityElement(children: .combine)
                .accessibilityAddTraits(.isHeader)
            )
            .cornerRadius(22)
            .padding(.horizontal, 20)
            .padding(.top, 8)

            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Unirme a EcoLearn")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(primaryText(dark))
                        Text(vm.ecoMode ? "Contribuyendo mientras cargas tu teléfono" : "Solo actúa mientras tu teléfono carga")
                            .font(.system(size: 12)).foregroundColor(secondaryText(dark))
                    }
                    .accessibilityHidden(true) // Ocultamos este texto porque el Toggle lo leerá de forma más limpia
                    
                    Spacer()
                    
                    Toggle("", isOn: Binding(
                        get: { vm.ecoMode },
                        set: { _ in
                            if vm.ecoMode { vm.disableEcoMode() } else { vm.requestEcoMode() }
                        }
                    ))
                    .labelsHidden()
                    .accessibilityLabel("Unirme a EcoLearn. \(vm.ecoMode ? "Contribuyendo mientras cargas tu teléfono" : "Solo actúa mientras tu teléfono carga")")
                    .tint(accentGreen)
                }

                if vm.ecoMode {
                    HStack(spacing: 8) {
                        Circle().fill(accentGreen).frame(width: 8, height: 8)
                            .scaleEffect(vm.isTraining ? 1.4 : 1.0)
                            .animation(.easeInOut(duration: 0.6).repeatForever(), value: vm.isTraining)
                        Text(vm.isTraining ? "Contribuyendo ahora..." : "En espera. Solo actúa al cargar")
                            .font(.system(size: 12, weight: .medium)).foregroundColor(accentGreen)
                        Spacer()
                    }
                    .accessibilityElement(children: .combine)
                }
            }
            .padding(18)
            .background(cardBackground(dark))
            .cornerRadius(22)
            .shadow(color: .black.opacity(0.06), radius: 10, x: 0, y: 4)
            .padding(.horizontal, 20)

            HStack(spacing: 12) {
                VStack(spacing: 6) {
                    Text(String(format: "%.1f kg", Double(vm.activeUsers) * 0.0016))
                        .font(.system(size: 20, weight: .bold)).foregroundColor(primaryText(dark))
                    Text("CO₂ ahorrado\nentre todos")
                        .font(.system(size: 11)).foregroundColor(secondaryText(dark)).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity).padding(14)
                .background(accentGreen.opacity(0.08)).cornerRadius(18)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("CO2 ahorrado entre todos: \(String(format: "%.1f", Double(vm.activeUsers) * 0.0016)) kilos")

                VStack(spacing: 6) {
                    Text("\(vm.activeUsers)")
                        .font(.system(size: 20, weight: .bold)).foregroundColor(primaryText(dark))
                    Text("Personas\ncontribuyendo")
                        .font(.system(size: 11)).foregroundColor(secondaryText(dark)).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity).padding(14)
                .background(accentBlue.opacity(0.08)).cornerRadius(18)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Personas contribuyendo: \(vm.activeUsers)")

                VStack(spacing: 6) {
                    Text(String(format: "%.0f L", Double(vm.activeUsers) * 0.12))
                        .font(.system(size: 20, weight: .bold)).foregroundColor(primaryText(dark))
                    Text("Agua no\ngastada")
                        .font(.system(size: 11)).foregroundColor(secondaryText(dark)).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity).padding(14)
                .background(Color.purple.opacity(0.08)).cornerRadius(18)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Agua no gastada: \(String(format: "%.0f", Double(vm.activeUsers) * 0.12)) litros")
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 32)
        }
    }
}

#Preview {
    ContentView()
}

//*

// ============================================================
// MARK: - TONALLI — CONTENTVIEW REAL (COMENTADO)
// ============================================================
// Punto de entrada real de la app con todos los entitlements,
// permisos, BGTask registration y lifecycle completo.
// ============================================================

// MARK: - App entry point real
// @main en TonalliApp.swift (no en ContentView)
// Registra el BGProcessingTask antes de que la app arranque
// para que iOS pueda ejecutar el entrenamiento en background
//
// import SwiftUI
// import BackgroundTasks
// import HomeKit
//
// @main
// struct TonalliApp: App {
//
//     // AppDelegate para manejar lifecycle y notificaciones con acciones
//     @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
//
//     // CoreData persistence controller compartido con widgets
//     let persistence = PersistenceController.shared
//
//     var body: some Scene {
//         WindowGroup {
//             ContentView()
//                 // Inyectar CoreData context en el environment de SwiftUI
//                 .environment(\.managedObjectContext, persistence.container.viewContext)
//                 .onAppear {
//                     // Registrar el BGProcessingTask ANTES de que la app
//                     // reciba la primera llamada del sistema
//                     // IMPORTANTE: debe registrarse aquí, no en el ViewModel
//                     BGTaskScheduler.shared.register(
//                         forTaskWithIdentifier: "com.tonalli.training",
//                         using: nil
//                     ) { task in
//                         TonalliViewModelReal.handleBackgroundTask(task as! BGProcessingTask)
//                     }
//                 }
//         }
//     }
// }

// MARK: - AppDelegate real para manejo de notificaciones con acciones
// UNUserNotificationCenterDelegate permite manejar cuando
// el usuario responde a una notificación desde la pantalla de bloqueo
// o el Centro de Notificaciones sin abrir la app
//
// class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
//
//     func application(
//         _ application: UIApplication,
//         didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
//     ) -> Bool {
//
//         // Activar monitoreo de batería desde el inicio
//         UIDevice.current.isBatteryMonitoringEnabled = true
//
//         // Configurar el delegate de notificaciones
//         UNUserNotificationCenter.current().delegate = self
//
//         // Registrar categorías de notificación con botones de acción
//         // Permite al usuario actuar sin abrir la app
//         let applyAction = UNNotificationAction(
//             identifier: "APPLY_PROFILE",
//             title: "Aplicar ahora",
//             options: .foreground
//         )
//         let dismissAction = UNNotificationAction(
//             identifier: "DISMISS",
//             title: "Ignorar",
//             options: .destructive
//         )
//         let profileCategory = UNNotificationCategory(
//             identifier: "PROFILE_SUGGESTION",
//             actions: [applyAction, dismissAction],
//             intentIdentifiers: [],
//             options: .customDismissAction
//         )
//         let turnOffCategory = UNNotificationCategory(
//             identifier: "DEVICE_SUGGESTION",
//             actions: [applyAction, dismissAction],
//             intentIdentifiers: [],
//             options: .customDismissAction
//         )
//         UNUserNotificationCenter.current().setNotificationCategories([
//             profileCategory, turnOffCategory
//         ])
//
//         return true
//     }
//
//     // Mostrar notificaciones aunque la app esté en primer plano
//     func userNotificationCenter(
//         _ center: UNUserNotificationCenter,
//         willPresent notification: UNNotification,
//         withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
//     ) {
//         // En producción: mostrar banner + sonido incluso con app abierta
//         completionHandler([.banner, .sound])
//     }
//
//     // Manejar respuesta del usuario a la notificación
//     func userNotificationCenter(
//         _ center: UNUserNotificationCenter,
//         didReceive response: UNNotificationResponse,
//         withCompletionHandler completionHandler: @escaping () -> Void
//     ) {
//         switch response.actionIdentifier {
//         case "APPLY_PROFILE":
//             // El usuario tocó "Aplicar ahora" desde la notificación
//             // Leer qué perfil aplicar del userInfo de la notificación
//             if let profileRaw = response.notification.request.content.userInfo["profile"] as? String,
//                let profile = UserProfile(rawValue: profileRaw) {
//                 // Publicar evento para que el ViewModel lo maneje
//                 NotificationCenter.default.post(
//                     name: NSNotification.Name("ApplyProfile"),
//                     object: profile
//                 )
//             }
//         case "DISMISS":
//             // El usuario descartó la sugerencia — registrar para no repetir
//             print("Sugerencia descartada por el usuario")
//         default:
//             // El usuario tocó la notificación sin acción → abrir la app
//             break
//         }
//         completionHandler()
//     }
// }

// MARK: - ContentView real con @Environment de CoreData
// La diferencia principal con la demo:
// 1. El ViewModel usa @StateObject con el ViewModel real
// 2. CoreData context se inyecta desde el environment
// 3. La tab de Energía usa datos reales de CoreData
// 4. Los dispositivos vienen de HomeKit, no hardcodeados
//
// struct ContentViewReal: View {
//     // ViewModel real con HomeKit, red neuronal y Federated Learning
//     @StateObject var vm = TonalliViewModelReal()
//
//     // CoreData context para lecturas de energía
//     @Environment(\.managedObjectContext) private var context
//
//     @State var selectedTab = 0
//     var dark: Bool { vm.isDarkMode }
//
//     var body: some View {
//         ZStack {
//             pageBackground(dark).ignoresSafeArea()
//             VStack(spacing: 0) {
//                 // Header idéntico a la demo
//                 headerView
//
//                 ScrollView(showsIndicators: false) {
//                     if selectedTab == 0 {
//                         HomeTabReal(vm: vm, dark: dark, selectedTab: $selectedTab)
//                     } else if selectedTab == 1 {
//                         EnergyTabReal(vm: vm, dark: dark)  // Datos de CoreData
//                     } else {
//                         EcoLearnTab(vm: vm, dark: dark)    // Igual a la demo
//                     }
//                 }
//
//                 // Tab bar idéntico a la demo
//                 tabBar
//             }
//         }
//         // Sheets de análisis de IA — idénticos a la demo
//         .sheet(isPresented: $vm.showAIResultSheet) { ... }
//         .sheet(isPresented: $vm.showProfileSheet) { ... }
//         .sheet(isPresented: $vm.showEcoPopup) { ... }
//         .sheet(isPresented: $vm.showEcoOnboarding) { ... }
//
//         // Observar evento de "Aplicar perfil" desde notificación
//         .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("ApplyProfile"))) { notification in
//             if let profile = notification.object as? UserProfile {
//                 vm.applyProfile(profile)
//             }
//         }
//     }
// }

// MARK: - HomeTab real con dispositivos de HomeKit
// La diferencia con la demo:
// 1. Los dispositivos vienen de HomeKit (no hardcodeados)
// 2. Si no hay dispositivos, se muestra onboarding de HomeKit
// 3. DeviceCard llama a vm.toggleDevice() para cambio real
// 4. El botón + abre HMAddAccessoryView para pairing real
//
// struct HomeTabReal: View {
//     @ObservedObject var vm: TonalliViewModelReal
//     let dark: Bool
//     @Binding var selectedTab: Int
//     @State var showAddDevice = false
//     @State var showHomeKitSetup = false
//
//     var activeCount: Int { vm.devices.filter { $0.isOn }.count }
//
//     var body: some View {
//         VStack(spacing: 20) {
//             // Mode cards — idénticos a la demo
//             HStack(spacing: 12) {
//                 ModeCard(title: "Vacaciones", ...) { vm.toggleVacationMode() }
//                 ModeCard(title: "Perfil", ...) { vm.showProfileSheet = true }
//                 ModeCard(title: "IA", ...) { vm.toggleAILearning() }
//             }
//
//             // Stat de ahorro — idéntico a la demo
//             Button { selectedTab = 1 } label: { ... }
//
//             VStack(alignment: .leading, spacing: 12) {
//                 HStack {
//                     VStack(alignment: .leading, spacing: 2) {
//                         Text("Dispositivos")
//                         Text("\(activeCount) de \(vm.devices.count) activos")
//                     }
//                     Spacer()
//                     // Botón + abre el pairing real de HomeKit
//                     Button { showAddDevice = true } label: {
//                         Image(systemName: "plus.circle.fill")
//                             .font(.system(size: 26))
//                             .foregroundColor(accentBlue)
//                     }
//                 }
//
//                 if vm.devices.isEmpty {
//                     // Onboarding cuando no hay dispositivos HomeKit configurados
//                     VStack(spacing: 12) {
//                         Image(systemName: "homekit")
//                             .font(.system(size: 48))
//                             .foregroundColor(accentBlue.opacity(0.5))
//                         Text("Sin dispositivos HomeKit")
//                             .font(.system(size: 16, weight: .semibold))
//                         Text("Agrega dispositivos compatibles con HomeKit para monitorear y controlar tu hogar.")
//                             .font(.system(size: 13))
//                             .multilineTextAlignment(.center)
//                         Button { showAddDevice = true } label: {
//                             Text("Agregar dispositivo")
//                                 .foregroundColor(.white)
//                                 .padding()
//                                 .background(accentBlue)
//                                 .cornerRadius(14)
//                         }
//                     }
//                     .padding()
//                 } else {
//                     // Grid de dispositivos reales de HomeKit
//                     LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
//                         ForEach($vm.devices) { $device in
//                             DeviceCardReal(device: $device, dark: dark, vm: vm, onDelete: {
//                                 vm.devices.removeAll { $0.id == device.id }
//                             })
//                             .frame(height: 140)
//                         }
//                     }
//                 }
//             }
//             .padding(.horizontal, 20)
//         }
//         .padding(.top, 8)
//         .padding(.bottom, 32)
//         // Sheet para agregar dispositivo via HomeKit pairing real
//         .sheet(isPresented: $showAddDevice) {
//             if let home = vm.primaryHome {
//                 // iOS 16+: vista nativa de HomeKit para escanear QR
//                 // AddAccessoryViewReal(home: home)
//                 //
//                 // iOS 15 fallback: instrucciones manuales
//                 AddDeviceInstructionsSheet(dark: dark, onDismiss: { showAddDevice = false })
//             }
//         }
//     }
// }

// MARK: - EnergyTab real con datos de CoreData
// La gráfica muestra kWh reales leídos de HomeKit cada 15 minutos.
// El picker Hoy/Semana/Mes filtra los datos del FetchRequest.
//
// struct EnergyTabReal: View {
//     @ObservedObject var vm: TonalliViewModelReal
//     let dark: Bool
//     @State var selectedRange = 0
//
//     // FetchRequests de CoreData para cada rango de tiempo
//     @FetchRequest(fetchRequest: EnergyReading.todayFetchRequest()) var todayReadings: FetchedResults<EnergyReading>
//     @FetchRequest(fetchRequest: EnergyReading.weekFetchRequest()) var weekReadings: FetchedResults<EnergyReading>
//     @FetchRequest(fetchRequest: EnergyReading.monthFetchRequest()) var monthReadings: FetchedResults<EnergyReading>
//
//     var currentData: [EnergyDataPoint] {
//         switch selectedRange {
//         case 0: return groupReadingsByHour(todayReadings)
//         case 1: return groupReadingsByDay(weekReadings)
//         default: return groupReadingsByWeek(monthReadings)
//         }
//     }
//
//     var body: some View {
//         // Idéntico a la demo pero con datos reales de CoreData
//         // Ver EnergyChartReal arriba para la implementación del agrupamiento
//         VStack(spacing: 20) {
//             // Consumo actual en kW — leído de HomeKit en tiempo real
//             Text(String(format: "%.2f kW", vm.totalConsumption))
//
//             // Gráfica con datos reales agrupados
//             EnergyChartReal(readings: currentData, dark: dark)
//
//             // Desglose por dispositivo — datos reales de HomeKit
//             ForEach(vm.devices.filter { $0.isOn }) { device in
//                 // Barra proporcional al consumo real del sensor
//             }
//         }
//     }
// }

// MARK: - Entitlements requeridos (archivo Tonalli.entitlements)
// En Xcode: Signing & Capabilities → + para agregar cada uno
//
// com.apple.developer.homekit = true
// → Acceso a dispositivos HomeKit del usuario
// → Sin esto, HMHomeManager no puede leer ni controlar nada
//
// com.apple.developer.background-tasks = true
// → Permite registrar BGProcessingTask para entrenamiento nocturno
// → Sin esto, BGTaskScheduler.shared.register() falla silenciosamente
//
// com.apple.security.application-groups = ["group.com.tonalli"]
// → Compartir datos entre la app, el widget y extensiones
// → Necesario para que el widget muestre el consumo actual
//
// com.apple.developer.icloud-container-identifiers = ["iCloud.com.tonalli"]
// → Sincronización de configuración entre dispositivos del usuario
// → NSPersistentCloudKitContainer usa este identificador

// MARK: - Info.plist requerido en producción
//
// NSHomeKitUsageDescription:
// "Tonalli necesita acceder a tus dispositivos del hogar
//  para monitorear y optimizar su consumo energético."
//
// NSLocationWhenInUseUsageDescription:
// "Tonalli usa tu ubicación para obtener temperatura exterior
//  y mejorar las recomendaciones de ahorro energético."
//
// NSMotionUsageDescription:
// "Tonalli detecta si estás en casa para activar el
//  modo de ahorro automático cuando te vas."
//
// BGTaskSchedulerPermittedIdentifiers:
// Item 0: com.tonalli.training
//
// UIBackgroundModes:
// Item 0: fetch
// Item 1: processing
//
// NSPrivacyCollectedDataTypes (iOS 17+ Privacy Manifest):
// - NSPrivacyCollectedDataTypeDeviceID (anonimizado, no vinculado a usuario)
// - NSPrivacyCollectedDataTypeProductInteraction (patrones de uso del hogar)
//
// NSPrivacyAccessedAPITypes (iOS 17+ Privacy Manifest):
// - NSPrivacyAccessedAPICategoryUserDefaults (para guardar pesos de la red neuronal)

